package spring.vo.product;

public class CategoryVO {

	private String category;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	@Override
	public String toString() {
		return "CategoryVO [category=" + category + "]";
	}
	
		
}
