package spring.vo.member;

public class NaverCommand {
	

	private String n_email;
	private String n_name;
	private String n_nickName;
	
	
	public String getN_email() {
		return n_email;
	}
	public void setN_email(String n_email) {
		this.n_email = n_email;
	}
	public String getN_name() {
		return n_name;
	}
	public void setN_name(String n_name) {
		this.n_name = n_name;
	}
	public String getN_nickName() {
		return n_nickName;
	}
	public void setN_nickName(String n_nickName) {
		this.n_nickName = n_nickName;
	}
	
	
}
