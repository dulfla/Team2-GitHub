package spring.vo.chat;

public class ChattingRoomInfoListVo {

	private String c_id;
	private String p_id;
	private String type;
	private String chatMember;
	private String p_name;
	
	public String getC_id() {
		return c_id;
	}
	public void setC_id(String c_id) {
		this.c_id = c_id;
	}
	public String getP_id() {
		return p_id;
	}
	public void setP_id(String p_id) {
		this.p_id = p_id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getChatMember() {
		return chatMember;
	}
	public void setChatMember(String chatMember) {
		this.chatMember = chatMember;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	
}
