package spring.exception;

public class RequiredException extends RuntimeException{

}
