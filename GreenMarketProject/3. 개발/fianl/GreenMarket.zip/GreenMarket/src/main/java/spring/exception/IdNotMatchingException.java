package spring.exception;

public class IdNotMatchingException extends RuntimeException{

}
