set define off;
--------------------------------------------------------------------------------------------------------------------

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'애어팟 맥스 팝니다AirPods Max s급입니다.거의 착용해본 적이 없어요'
,'AirPods Max s급입니다，겉포장이 있어요

거의 착용해본 적이 없어요

보증기간은 2023년 7월까지입니다

거치대와 수납함 증정

가격흥정안돼요.
현장거래만 연락주세요.'
,'디지털 기기','2023/01/28',0,520000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'airpotmax.jpg', '2023\01\28', '1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'아이폰 Xs 배터리 90% 이상 64G'
,'구성은 사진과 같습니다 지인이 줬는데 팔아봅니다
카메라만 따로 팔아도 5만원 나옵니다
상태 모릅니다 환불 불가능합니다'
,'디지털 기기','2023/01/30',100,80000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'iphone12a.jpg', '2023\01\30', '2');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'iphone12b.jpg', '2023\01\30', '3');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'에어팟프로2 [단순개봉]'
,'11월에 산 제품 단순개봉 하고 페어링만하고 안 썼습니다!!
직거래 , 택배거래 가능'
,'디지털 기기','2023/01/30',7,280000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'airpotpro2.jpg', '2023\01\30', '4');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'airpotpro2.jpg', '2023\01\30', '5');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'아이맥24'
,'아이맥 24 M1 8코어 GPU 7코어 RAM 8GB SSD 256GB 실버

2021년 12월 13일 구매
상태 완전 최상 보장합니다! 
개봉해서 정말 가끔 웹서핑이나 영화본게 전부구요
거의 집에 붙어있을 시간이 없어서 사용을 거의 안했습니다! 
딱 저렇게 기본사항 이구요! 더 궁금하신 사항은 언제든 문의 주세요!
(키보드는 터치아이디 탑재형 아니에요!!)

구매 후에는 환불 안되시니 신중히 결정 부탁드려요!!
******쿨거시 네고!!!!!!!'
,'디지털 기기','2023/01/30',292,1470000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'iMac.jpg', '2023\01\30', 'q');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'iMac.jpg', '2023\01\30', 'qq');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'iMac.jpg', '2023\01\30', 'qqq');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'닌텐도 스위치 라이트 더콰이즈'
,'닌텐도스위치라이트
충전기필요하면 드리는데 돼지코끼워서하셔야하고
돼지코없으시면 충전기그냥 드립니다
구매하시면 케이스도 증정으로드립니다'
,'디지털 기기','2023/01/27',4,170000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'NintendoSwitch.jpg', '2023\01\27', 'ns');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'NintendoSwitch.jpg', '2023\01\27', 'nsns');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'(애플) 아이패드 m1 프로 3세대 스그 11인치 wifi +애플팬슬2+애플 공홈 정품 터치콤보 케이스 처분합니다.'
,'2022년 3월 구매
맥북을 주로 사용해서 사용감 극히 적습니다.
늘 터치콤보 케이스 사용해서 상처 없습니다.
강화유리 붙혀져 있습니다.
터치콤보 케이스는 각 모서리에 약간의 색바램 있습니다. (파우치에 계속 들어가있어서.)

아이패드, 펜슬은 풀박스이며, 터치콤보는 케이스 없습니다.

각각 거래도 가능하니 가격 적어서 연락주세요~'
,'디지털 기기','2023/01/29',447,1200000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ipad.jpg', '2023\01\29', 'ip');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ipad.jpg', '2023\01\29', 'ipip');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ipad.jpg', '2023\01\29', 'ipipip');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'삼성 노트북 15.6인치 NT270E5K(+삼성 유선 마우스,무선충전패드,브리츠스피커 드립니다)'
,'삼성전자 노트북 NT270E5K-K25WS 판매합니다
*어댑터, Key스킨 포함
구매하시면 삼성 정품 유선 마우스+무선 충전 가능한 마우스패드+브리츠 스피커(BR-ISTANA) 도 함께 드려요

16년 여름 쯤 구매해서 1년 정도만 사용 후 보관해서 전체적으로 상태 좋습니다

망포역 인근 아파트로 직접 가지러 와주셔야 하고
중고거래 특성 상 교환 환불은 불가합니다

[상세 스펙]
39.62cm(15.6인치) / 인텔 / 펜티엄 / 브로드웰 / 3825U (1.9GHz) / 듀얼코어 / 1366x768 / 눈부심방지 / LPDDR3(온보드) / 4GB / SSD / 128GB / DVD레코더 / HD Graphics / VRAM:시스템메모리공유 / 유선랜 / 802.11 b/g/n 무선랜 / 블루투스 4.0 / HDMI / D-SUB / 웹캠 / USB 3.0 / USB 2.0 / SD카드 / 숫자 키패드 / 48Wh / 윈도우10 / 두께: 30mm / 2.3kg / 일반유통상품 / 용도: 사무 / 색상: 화이트'
,'디지털 기기','2023/01/26',208,120000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'notebook.jpg', '2023\01\26', 'nb');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'notebook.jpg', '2023\01\26', 'nbnb');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'샤오미 블루투스 무선 이어폰(청춘판 한국어버전/TWSEJ02LM)샤오미 이어폰'
,'가격 인하 없음

샤오미 에어닷 블루투스 이어폰(청춘판 한국어버전TWSEJ02LM)무선 이어폰

정상 작동
이어팁 소독
충전 완료'
,'디지털 기기','2023/01/30',74,6000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'mi.jpg', '2023\01\30', 'mi');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'mi.jpg', '2023\01\30', 'mimi');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'게이밍 컴퓨터 풀세트/고사양 컴퓨터 풀세트/오토캐드 컴퓨터 풀세트 배그컴퓨터 오버워치 컴퓨터 1060,rx580상위'
,'배그 오버워치 롤 피파 다 돌아갑니다.
먼지청소 되어있어요.

사양입니다.

Cpu : I7-3770
Ram : 16gb
Ssd : 250gb
Hdd : 1tb
Power : 700w
그래픽카드 : gtx 1060 6기가

모니터 : 24인치 게이밍 모니터
구성품 : 게이밍 모니터 마우스 키보드 게이밍 스피커 본체 각종 연결선들'
,'디지털 기기','2023/01/31',314,540000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'com.jpg', '9999\99\99', 'co');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'com.jpg', '9999\99\99', 'coco');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'캐논 450D DSLR 기본 풀세트'
,'사진과 영상이 취미이기에 결혼때 구매 했던 DSLR입니다.
구매년 2009년 10월 정도에 구매했고
사용에는 전혀 문제가 없습니다.(오늘 촬영해봄)

사진과 같이 구성품 설명
- 450D 바디
- 번들렌즈(18~55mm/Stabilizer기능)
- Keva 58mm UV필터 약간 찌그러짐(사용엔 문제 없음)
- 충전기 1개
- 배터리 1 개(캐논 정품)
- AV케이블 1개(캐논 정품)
- 4핀케이븡 1개(캐논 정품)
- 바람흡/배기(청소용)
- 니콘 DSRL파우치
- 캐논 정품 번들 가방
- USB연장케이블 1M 1개
- McroSD 16GB
- SD카드 리더기

연식이 좀 있지만 입문용으로는 가성비 넘치는 제품 입니다.

교환 반품은 되지 않으니 참고 해주시고
채팅 주세요'
,'디지털 기기','2023/01/31',472,140000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'canon.jpg', '9999\99\99', 'ca');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'canon.jpg', '9999\99\99', 'ca1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'마샬 메이저4, 마샬 헤드폰'
,'마샬 메이저4 헤드폰 입니다
20만원 초반에 구입해서 3번 사용했습니다

정품인증서 있어서 정품 등록하시면 됩니다

강동역에서 직거래만 합니다
내고 사절
구매하실 분만 연락주세요

정품문의 사절합니다ㅠㅠ
가품 사본적도 없고 써본적도 없습니다
정품보증서가 있는데 더이상 어떻게 확인을 시켜드릴지 모르겠습니다ㅠㅠ

구매 의사 있으신 분만 연락주세요..'
,'디지털 기기','2023/01/30',138,140000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Marshall.jpg', '9999\99\99', 'ma');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Marshall.jpg', '9999\99\99', 'ma1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Marshall.jpg', '9999\99\99', 'ma2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'소니 WH-1000XM5 블루투스 헤드셋'
,'🎧
2022. 7월 쿠팡에서 구매 후 
정품등록 해놓았습니다^^

에어팟프로를 사용중이라 
구매 후 한번 충전 해서 3-4번 실사용 했습니다.

하자, 오염 없습니다.

사진에 나와 있듯이 겉 박스, 
케이스, 충전선, 유선 연결선 모두 있습니다.'
,'디지털 기기','2023/01/31',18,370000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sonyxm5.jpg', '9999\99\99', 'sx');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sonyxm5.jpg', '9999\99\99', 'sx1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sonyxm5.jpg', '9999\99\99', 'sx2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'보조배터리, 카카오보조배터리, 춘식이 보조배터리, 포켓보조배터리, (미개봉, 새상품)'
,'정가: 29,000원마지막 사진처럼 카카오에서 판매중인
포켓 보조배터리 춘식이입니다!!
본체, C타입 케이블 모두 새 상품이며 개봉도 하지않았습니다!! 어서 가져가세요~

가격 조정 가능하니 연락주세요!'
,'디지털 기기','2023/01/29',231,21000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'choonsik.jpg', '9999\99\99', 'cs');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'choonsik.jpg', '9999\99\99', 'cs1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'레안텍 모니터27인치 모니터(3개월사용)'
,'구입후 3개월 사용했습니다
거의 새 모니터 입니다'
,'디지털 기기','2023/01/31',75,200000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'monitor.jpg', '9999\99\99', 'mo');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'monitor.jpg', '9999\99\99', 'mo1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'MacBook Air 맥북에어 M1 8g 512ssd SS급'
,'작년 21년 5월 구입했습니다

맥북병이 도져서 구매했으나 .. 코시국 zoom회의 말고는 일절 사용할 일이 없어 판매합니다…
제 방을 벗어난 적이 없어 흠집, 오염 하나 없는 S급입니다. 안눌러본 버튼도 있을 정도로……. 새것..

풀패키지 그대로 포장해 드리겠습니다.
**맥북용 블루투스 마우스, 키보드 보호패드. 같이 드릴게요!

필요하신 사항 있으시면 채팅 주세요!

Apple 맥북 에어 13 스페이스그레이
(M1/512GB/8GB/MAC OS)

[제품정보]
- 색상 : 스페이스 그레이
- CPU모델명 : M1
- 저장용량 : 512GB
- RAM용량 : 8GB
- 운영체제 : MAC OS

[제품상태]
- 최상급 (풀박)/ 기스,찍힘 없음
- 배터리 성능 100%'
,'디지털 기기','2023/01/30',75,1050000,'37.266050258427526','126.99980552551798');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'macbook.jpg', '9999\99\99', 'mb');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'macbook.jpg', '9999\99\99', 'mb1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'macbook.jpg', '9999\99\99', 'mb2');
----------------------------------------------------------------------------------------------------------------------

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'다이슨 V6 무선 청소기'
,'다이슨 V6 무선 청소기 팝니다.

구성품은 본체, 청소봉, 청소헤드, 충전기, 도킹스테이션 입니다.
배터리 완충기준 약 10분 작동합니다.
사진과 같이 상태 양호하며, 이상없이 잘 작동합니다.
직거래만 하고 있습니다.(잠실3동)'
,'생활가전','2023/01/30',100,50000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dyson.jpg', '2023\01\30', '6');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dyson.jpg', '2023\01\30', '7');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'전자레인지'
,'중고 전자레인지

사용감 있으며, 사진 참고 부탁드립니다.

직거래만 가능하며,
대전 용문역에서 가능합니다.

편하게 문의주세요.'
,'생활가전','2023/01/28',45,30000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'microwave.jpg', '2023\01\28', 'a');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'microwave.jpg', '2023\01\28', 'b');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'microwave.jpg', '2023\01\28', 'c');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'삼성 공기청정기 판매합니다'
,'삼성 공기청정기 판매합니다 
겉면  상태  깨끗합니다  필터도  상태
양호합니다
한동안  안쓰다  필요없어 판매할려고
전원켜보니  약간의 소음이 나는 정도 입니다
업소나 사무실 넓은데는 거의 신경안쓰셔도 
될것 같습니다 
그래서  싸게  처분합니다
50000원 판매합니다 
직거래 강남구쪽에서 합니다 
***-****-**** 문자주세요'
,'생활가전','2023/01/30',45,50000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Airpurifier.jpg', '2023\01\30', '8');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Airpurifier.jpg', '2023\01\30', '9');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'삼성 50인치 티비 + 고가의 티비받침대 이사로 급해서ㅠ 티비값에 받침대까지'
,'삼성 TV 50인치와 고가의 티비 받침 거치대. 무척 깨끗하고 성능좋고 잘나와요
수준은 보시면 알겠지만 새거급이에요
거의 쓰지않고 전시용으로 둬서요
저의 판매물품 보시면 아시겠지만 큰집살다 작은집이사와서 티비만 10대 넘게 가지고 있어서 그냥 조각처럼 디피용으로 두기만 하고 어쩌다 가끔 틀어봐서 너무나 깔끔합니다 지금도 쓰지도 않고 거실복도 한켠에 세워두고만 있네요 이젠 원룸으로 이사가야되서 다 처분중임다
티비가 열대 넘게 있었던지라 몇년식인지는 가물가물이고 뒷면이 뿌옇게 지워져서 잘 안보이네요
작년 2022년 11월 말에 55만원에 팔렸었는데 남의편으로 집에 사는 남자가 회사에서 회의실 프레젠터이션 하는 용도로 일주일에 한번씩 써야할 일이 생겼다고 해서 가져갔다가 어제 가져왔네요
그때 저하고 엄청 싸웠네요 니가 회사 물건 다대주냐 팔린걸 왜가져가냐하고 남의편께서는 결코 나의 편을 들지않고 해서...결국 구매자분께 찾아가서 작은선물 드리고 미안하고 죄송하다고 백배사죄하였던거네요
티비에 딸린 받침 없어요
티비만 따로 벽걸이브라켓 구하셔서 거실수 있어요
티비 가격만 430000원
티비받침 가격만 220000만
엄청난 쇠로 만들어진
세련되고 공간절약과 센스의 티비 거치대
네고안합니다 사실분만 연락주시면 쿨거래시 알아서 잘해드려요
승용차에 들어갑니다'
,'생활가전','2023/01/31',789,428000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tv.jpg', '9999\99\99', 'tv');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tv.jpg', '9999\99\99', 'tv1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tv.jpg', '9999\99\99', 'tv2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'제습기 리큅저소음제습기 12L LDF 072501'
,'작년에 구입.
너무 멀리 이사를 해야해서...들고가질못해
정리합니다. 오늘부터 2월6일까지.
반품불가합니다.'
,'생활가전','2023/01/31',116,100000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'lequip.jpg', '9999\99\99', 'le');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'lequip.jpg', '9999\99\99', 'le1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'[초저렴] 살균기, 초음파세척기, 칫솔살균기'
,'미개봉 새제품입니다.
3개 한 묶음으로만 팝니다.
개인위생이 중요한 시기에
필요하신 분들 싸게 가져가세요:)

1. HABBSI 무선충전기 겸 살균기
- 정가 : 29,000원
- 휴대폰 살균 중 무선충전 기능 지원

2. WHIA 초음파 세척기
- 정가 : 29,000원
- 브러쉬, 안경, 생활소품 등 초음파로 세척

3. 아이리버 칫솔 살균기
- 정가 : 24,900원
- 애기들이 좋아하는 칫솔 세척기'
,'생활가전','2023/01/31',117,34000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sterilizer.jpg', '9999\99\99', 'sz');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sterilizer.jpg', '9999\99\99', 'sz1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'현재가23만원 인덕션 삼성전자인덕션 삼성인덕션'
,'한두번 썼어요
인덕션있는 집으로 이사가게 되어
팝니다'
,'생활가전','2023/01/30',102,170000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Induction.jpg', '9999\99\99', 'ind');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Induction.jpg', '9999\99\99', 'ind1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'쿠팡현재가20만원 에어프라이어 에어프라이기 에어프라이 매직쉐프 전기오븐기기 10리터입니다'
,'현재 쿠팡에서 20만원에 팔고 있어요
10리터라 용량 큽니다

몇개월쓰다가 오븐기 있는 집으로
이사가게되어
판매합니다
쎄거같은 중고입니다
득템하세요'
,'생활가전','2023/01/28',99,70000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'airfryer.jpg', '9999\99\99', 'af');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'airfryer.jpg', '9999\99\99', 'af1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'히터/컨벤션히터/욕실히터/EMK/ECP-10D'
,'코스트코에서 구입힌여 짧게 사용한 EMK 컨벡션히터 EK-10D 판매합니다. 사용기간 짧아서 상태 좋습니다^^♡♡♡♡♡
스탠드/벽걸이 가능합니다.
욕실용 생활방수 됩니다.^^
장점은 욕실에서 애기들 씻기 5-10분전 틀어 놓으면 따뜻 따뜻 해요~^^

1.구입금액 :158,000원
2.판매금액 : 45,000원

거래장소는 주말에 외근시 집근처면 갔다 드리기도 해요~경비실까지만.
아님 택배 픽업 가능하셔요~~'
,'생활가전','2023/01/30',59,45000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'heater.jpg', '9999\99\99', 'ht');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'heater.jpg', '9999\99\99', 'ht1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'2달 사용한 uv크리스탈 제빙기 스테닉 대한민국 제빙기 DIM-0151'
,'최신형으로 출시된지 6개월 이내된 제품입니다. 모든 구성 잇고 찍힘 없어요'
,'생활가전','2023/01/30',26,200000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'icemachine.jpg', '9999\99\99', 'icemachine1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'icemachine.jpg', '9999\99\99', 'icemachine2');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'icemachine.jpg', '9999\99\99', 'icemachine');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'릴렉스건 마사지기 마사지건 휴대용마사지'
,'스마트 마사지건이에요 실사용 2회입니당
기스나 하자없고 새상품이랑 컨디션차이없어요~
본체 + 헤드6개 + 충전선 + 설명서 + 전용파우치 그대로 다 있어요 .

시중에 나온 휴대용 마사지기기중에
제일 최신 AI 센서 기술 적용되어 있는거구
가벼운데 파워좋아요 ◡̈ 파워는 4단계로 조절가능해요!

헤드가 다양해서 사용할 신체부위에 맞는 헤드로
전신 마사지 가능해요.
더 자세한 정보는 링크 걸어둘게요

쿨거시 네고가능합니다'
,'생활가전','2023/01/29',62,70000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'massagegun.jpg', '9999\99\99', 'msg');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'massagegun.jpg', '9999\99\99', 'msg1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'헬로키티 헤어 드라이어 / 미니 드라이기 / 접이식 헤어 드라이어 / 여행용 드라이기'
,'산리오 헬로키티 헤어 드라이기에요
미니사이즈지만 초미니는 아니라 바람도 짱짱해요
게다가 접이식이라 여행용 드라이어로도 딱이에요!

냉풍되고 바람세기도 2단 조절 가능합니다!
정상 작동잘되구요
본체는 거의 새것 처럼 깨끗하고
코드부분만 살짝 사용감있지만
사용에는 전혀 문제없어요

사실 키티라 그냥 둬도 넘 귀엽습니다

교환, 환불 불가

일반택배 +3000원 추가
(도로명 주소로 알려주세요/ 구 주소X)

CU반값택배 +2000원 추가
(CU편의점 점포명 알려주세요)'
,'생활가전','2023/01/30',27,10000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'hellokitty.jpg', '9999\99\99', 'hk');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'hellokitty.jpg', '9999\99\99', 'hk1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'hellokitty.jpg', '9999\99\99', 'hk2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'김치 냉장고와 양문 냉장고'
,'이사정리품입니다
작동잘됩니다 문제없어요
차량에실려있어서 바로배송합니다
관심톡주세요
년식이있어서저렴하게올려요 2007년'
,'생활가전','2023/01/30',173,150000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'kimchi.jpg', '9999\99\99', 'kimchi');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'kimchi.jpg', '9999\99\99', 'kimchi1');


INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'일리 커피머신 Y3.2 + 블랑코 커피머신 클리너'
,'일리 커피머신 Y3.2 거의 사용하지 않아 올립니다. 사용가이드와 커피머신 클리너도 같이 드립니다. 박스가 없어 택배거래는 불가하고 직거래 하려합니다. 관심있으신 분은 챗 부탁드려요~'
,'생활가전','2023/01/30',127,40000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'illy.jpg', '9999\99\99', 'illy');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'illy.jpg', '9999\99\99', 'illy1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'illy.jpg', '9999\99\99', 'illy2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'다이슨 에어랩-개봉만 한 상품(국내 다이슨사이트에서 구매.정품인증 가능)'
,'다이슨 에어랩(택배 상자와 상자까지 그대로 있음) 설명서도 그대로 있구요, 짧은 머리라...사고나서,테스트 용으로 한번 해봤어요.

진짜 새거예요....ㅠㅠㅠ아까운데....ㅠ
전 머리가 짧아 잘 안사용해서, 팔아요...ㅠ

상자채 그대로,있고,국내에서 (다이슨 공식 홈페이지에서 )작년에 구매해서 정품인증도 가능한 제품입니다.(설명서 안에 인증서 포함-정품인증서와 2년품질보증되는 설명서 다 있습니다.)'
,'생활가전','2023/02/01',157,560000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dysonhair.jpg', '9999\99\99', 'dsh');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dysonhair.jpg', '9999\99\99', 'dsh1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dysonhair.jpg', '9999\99\99', 'dsh2');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dysonhair.jpg', '9999\99\99', 'dsh3');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dysonhair.jpg', '9999\99\99', 'dsh4');


----------------------------------------------------------------------------------------------------------------------
--생활주방

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'인덕션냄비 편수 양수 찜솥 곰솥 전골 자루 냄비 4종'
,'인덕션사용가능합니다~
미사용이긴한데
곰솥 ~ 3번사진 표시부분 살짝 들어갔어요
전골 ~ 내부 라인있는데 연마제 같기도 해요
자루 ~ 외부표면 중간아래부분
           색이 약간 흐려요
전골,찜솥 ~ 외부바닥 얼룩및 기스 있습니다
편하게 막사용 하실분 구매하세요
직접오시거나 배송료 부담시 택배가능합니다'
,'생활주방','2023/01/29',45,40000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Induction.jpg', '2023\01\29', 'z');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Induction.jpg', '2023\01\29', 'zz');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'시라쿠스 크리머,저그'
,'왜이리 착하게 생긴거니 너는 ㅎㅎㅎㅎ


자꾸 마음가게만드는 청초한 꽃다발을 
지닌녀석^^ 





요즘은 꼭 우유 서빙이 아닌 
샐러드 소스나 , 티포크 꽂아두거나 
미니 화병으로도 요리죠리 응용해서 사용하시더라구요^^ '
,'생활주방','2023/01/26',71,32000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Syracuse.jpg', '2023\01\26', 'zzz');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Syracuse.jpg', '2023\01\26', 'zzzz');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'(새상품)중식도 식칼 3종 세트'
,'중식도 식칼 3종 새상품팝니다.
사이즈 및 중량은 마지막 사진 확인해주세요. 

편의점 선불택배 가능 (+3000)
반값택배 가능 (+1500)
착불택배 가능  

개인 중고거래 특성상 구매후 환불은 어렵습니다.
찔러보기, 가격흥정 정중히 사양합니다. ?
매너있는 거래원해요 '
,'생활주방','2023/01/30',18,17000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Chinesefoodknife.jpg', '2023\01\30', 'x');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Chinesefoodknife.jpg', '2023\01\30', 'xx');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'냉장고걸이 키친타올걸이 주방정리 양념통 주방용품 선반'
,'사이즈 생각보다 커요.
가로 30
폭 10
세로 68

생각보다 엄청나게 튼튼해서
맨 밑에 고리에
커다란 후라이팬과 웍을 몽땅 걸어도
안떨어질만큼 강력해요.

퐁퐁으로 한번 닦아놨는데 개인차가 있겠지만
크게 더럽거나 구부러진 곳 없이
깔끔하다고 생각해요.

키친타월, 조미료통, 프라이팬 등등
한번에 해결 가능해서 편합니다.

안팔리면 제가 그냥 쓰면 되니까
네고문의 사양해요.'
,'생활주방','2023/01/30',349,15000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tlqkf.jpg', '9999\99\99', 'qkf');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tlqkf.jpg', '9999\99\99', 'qkf1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'밥솥 토스트기 보관장 주방정리 주방 수납함'
,'이사가기 전에 싸게 내놓아요. 새로운 아파트 입주해서 물건 정리중입니다.
일정은 조정하셔야 합니다. 1층까지 내려드려요.
사용감 있지만 닦아쓰시면 아주 깨끗할거에요

밥솥과 토스트기 광파오븐은 팔지 않고
"수납함"만 팝니다.

62cm * 118cm * 60 cm 정도되네요'
,'생활주방','2023/01/30',349,15000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tlqjf.jpg', '9999\99\99', 'qjf');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tlqjf.jpg', '9999\99\99', 'qjf1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'[(새)주방수납가구] 슬라이딩 렌지 주방 수납장'
,'직접 방문하셔서 싣고 가져가실 수 있는 분만 연락 부탁드립니다. (잠실새내역 근처)

- 상부장, 하부장 연결하지 않은 새상품입니다.
- 미연결 상태라 분리해서 싣고 갈 수 있고, 이후 동봉된 나사로 연결이 필요합니다.
- 생각보다 기존 가구와 어울리지 않아 재판매해요.
- 착불비(2만원) 제외 및 정가보다 할인된 금액으로 판매합니다.'
,'생활주방','2023/01/29',556,175000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tmffkdleld.jpg', '9999\99\66', 'tmffkdleld');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tmffkdleld.jpg', '9999\99\66', 'tmffkdleld1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'주방식탁등 주방등 (골드)'
,'설치 1년 (노란빛)

필요하신분 저렴히 가져가세요~^^
상자에 보관해 두었습니다'
,'생활주방','2023/01/29',260,52000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wnqkdemd.jpg', '9999\99\66', 'wnqkdemd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wnqkdemd.jpg', '9999\99\66', 'wnqkdemd1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'반찬용기 - 밀페용기 새것'
,'전자렌지 사용가능하고요
유리입니다
새것입니다
820ml 입니다
원터치방식
프랑스 브랜드입니다
두개 모두 가격'
,'생활주방','2023/01/29',49,5000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'alfvP.jpg', '9999\99\66', 'alfvP');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'alfvP.jpg', '9999\99\66', 'alfvP1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'주방용품 주방정리 일괄ㅡ새상품'
,'모두 보관만 한 새상품입니다
스타벅스 리유저블 컵
나무스푼들
위생랩 행주들
주방에 물건이 너무 많아
복잡해 정리해요
저렴히 가져가세요'
,'생활주방','2023/01/30',457,5000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tmxkqjr.jpg', '9999\99\66', 'tmxkqjr');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tmxkqjr.jpg', '9999\99\66', 'tmxkqjr1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'주방등/인테리어등/식탁등'
,'동탄 호수공원 레이크 푸르지오
와서 가지고 가세요 :)

19년 첫입주시 달려있었고
바로 교체해서 안썼습니다'
,'생활주방','2023/01/30',457,5000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlrjsahn.jpg', '9999\99\66', 'dlrjsahn');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlrjsahn.jpg', '9999\99\66', 'dlrjsahn1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'제니퍼룸 오븐+오븐크리너, 미니오븐, 오븐'
,'사용한 지 1년반 되었고
정말 잘 작동해서 마지막 사진처럼 오븐 요리, 다이어트 요리도 잘해먹었어요.
예뻐서 여기저기 두기도 좋아요.♡

오븐크리너로 세척해두었고, 400ml 정도 남은 오븐크리너액도 같이 드립니다.'
,'생활주방','2023/01/30',223,17000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dhqms.jpg', '9999\99\66', 'dhqms');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dhqms.jpg', '9999\99\66', 'dhqms1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'제빵기 (미사용) 빵이금값 전기 반죽믹스기, 빵틀, 와플구이 등등 제빵용품'
,'제빵 및 전기와플기 모두
일괄 팝니다'
,'생활주방','2023/01/31',560,25000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wpQkd.jpg', '9999\99\66', 'wpQkd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wpQkd.jpg', '9999\99\66', 'wpQkd1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'화이트 일리 커피머신 프란시스 X7.1 커피머신 판매합니다.'
,'일리 커피머신 일리 프란시스 X7.1 커피머신 일리 ET커피머신 판매합니다!
1년정도 사용했습니다.
작동 이상 없고 다른 모델에 비해 압력 세서 커피 맛 좋아요!!
이사가게되어 작은 커피머신으로 교체하려고 판매합니다.
구매 원하시는 분은 채팅 주세요!'
,'생활주방','2023/01/31',77,70000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlffldlffl.jpg', '9999\99\66', 'dlffldlffl');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlffldlffl.jpg', '9999\99\66', 'dlffldlffl1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'크라움 스텐냄비 3종 세트 편수냄비 양수냄비 전골냄비 16cm+18cm+24cm 인덕션냄비'
,'(새제품)
16편수 + 18양수 + 24전골
인덕션 가능'
,'생활주방','2023/02/01',125,40000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zmfkdna.jpg', '9999\99\66', 'zmfkdna');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zmfkdna.jpg', '9999\99\66', 'zmfkdna1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'Sk식기세척기 6인용 식기세척기 판매합니다'
,'금토일 거래 가능합니다

Sk식기세척기 6인용 판매합니다

구매당시 사은품으로 준 세제를 거의 안썻을 정도로 새 상태입니다 세제도 같이 드립니다
실사용 횟수 5회미만 사용 입니다
좋은 주인 찾아가길 바랍니다'
,'생활주방','2023/02/01',603,300000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tlrrltp.jpg', '9999\99\66', 'tlrrltp');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tlrrltp.jpg', '9999\99\66', 'tlrrltp1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tlrrltp.jpg', '9999\99\66', 'tlrrltp2');

----------------------------------------------------------------------------------------------------------------------
--유아동

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'자라 아동 털 점퍼(116)베이지 겨울점퍼 아동털점퍼 아동외투 자라털코트'
,'자라 후드 털 점퍼
모자 탈부착안되는 일체형입니다
사이즈:116
색상:베이지색
부드러워요
내부 지퍼 올리는 부분이
아이가 올리다 찝힌부분있어요'
,'유아동','2023/01/30',137,5000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zara.jpg', '9999\99\99', 'zar');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zara.jpg', '9999\99\99', 'zar1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zara.jpg', '9999\99\99', 'zar2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'아동용자전거~알톤 20인치 아동용 자전거 7단 알미늄 010-8989-1235'
,'20인치 알미늄차체 휠알미늄 소비자가격₩289000'
,'유아동','2023/01/31',22,150000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'alton.jpg', '9999\99\99', 'alton');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'alton.jpg', '9999\99\99', 'alton1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'유아 장난감. 유아자동차. 유아흔들목마 리틀포레스트 흔들말&씽씽이 루디'
,'리틀포레스트 루디입니다.
중고이니 당연히 사용감은 있습니다. 엉덩이 뒤쪽 꼬맨부분있으나 사용하는데 문제없음. 이염 있는데 얼룩제거사용하시면 지워질듯해요.사진 자세히 첨부.
체크무늬가 이뻐서 집 디자인용으로 두거나 돌잔치 사진찍는용으로도 사진 너무 이쁘게나옵니다.
14만원에 구매했었습니다. 에눌X
직거래 중마초근처 버스정류장 번호 05-122
챗주세요.'
,'유아동','2023/01/30',276,30000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'horse.jpg', '9999\99\99', 'hor');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'horse.jpg', '9999\99\99', 'hor1');  
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'horse.jpg', '9999\99\99', 'hor2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'21-22 레알 마드리드 홈 유아 유니폼 키즈 유아복 아동복'
,'99000원 구매 후 사이즈 미스로 사용x
거의 새상품 입니다
사이즈는 3-4y 인데 돌때부터 만4세까지 입히실 수 있으세요^^'
,'유아동','2023/02/01',117,89000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'RealMadrid.jpg', '9999\99\99', 'realm');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'RealMadrid.jpg', '9999\99\99', 'realm1');  

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'치코 부스터(휴대용유아의자, 이유식의자, 유아캠핑용)'
,'치코 유아부스터

이유식시기나 아가들 어디다닐때 쓰기좋아요.

서브용으로 시댁이나 친정 요런데 두고 쓰시기도 좋아요.
저희는 서브용으로 시댁에 두고쓰다가
아이가 다커서 내놓습니다.
사용기간이 길지않으니 저렴히 사서 쓰셔요~~~

깨끗히 닦아두엇습니다

환불불가입니다^^

북서울꿈의숲 서문 근처 아파트 비대면 직거래합니다'
,'유아동','2023/01/31',71,5000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'chair.jpg', '9999\99\99', 'chair');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'chair.jpg', '9999\99\99', 'chair1'); 

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'피에고 유아 가방 유아 백팩'
,'세탁 안 하고 한 번인가 메고 나갔었어요.
미아방지끈은 한 번 해보니 애기가 달려가다 넘어져서 안 썼는데 어디 갔는지 모르겠어서 싸게 팝니다.
최저가 3만원 넘어요.
쿨거래시 네고 가능!'
,'유아동','2023/01/31',114,15000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'fiego.jpg', '9999\99\99', 'fie');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'fiego.jpg', '9999\99\99', 'fie1'); 
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'fiego.jpg', '9999\99\99', 'fie2'); 

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'야마토야 유아책상의자쿠션포함+유아의자 끼워줌'
,'야마토야 책상의자 색깔 이쁘고 쿠션은 새느낌 득템하세요
마지막 유아의자 드림
( 미니키보드랑세트였던의자네요)
책상 가로 70, 세로 38, 높이 48
나무의자는 사서 초반에 금이가서 수리해서 사용함 사용시 불편한점 없음
아이가 좋아해요 사용감은 약간 있으나 실용적 스티커만 떼고 하면 페인트상태는 매우 좋음
처음사진에 보면 아이성장에 따라 책상과 의자 모두 나사로 높이조절가능 간단함'
,'유아동','2023/01/31',326,5000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'hhh.jpg', '9999\99\99', 'hhh');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'hhh.jpg', '9999\99\99', 'hhh1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'유아 소파, 유아 빈백'
,'올 봄에 아기 사진촬영 해주느라 구매했었는데
사용을 안하게 되어서 판매합니다 :)

전체적으로 깨끗하고 오염도 없어요~
커버는 따로 분리해서 세탁도 가능합니다.
속 빵빵하고 예쁜 하늘색입니다~'
,'유아동','2023/01/30',736,13000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sofa.jpg', '9999\99\99', 'sof');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sofa.jpg', '9999\99\99', 'sof1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sofa.jpg', '9999\99\99', 'sof2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'유아블록 팔아요.+유아퍼즐매트'
,'블록 양이 많아서 한 통에 다 안 들어가네요.
베베블록 아니고 작은 사이즈 블록입니다.
두 통 일괄 가격입니다. 퍼즐매트는 퍼즐맞추기나 집 만들기, 상자만들기, 매트 등으로 활용 가능해요. 16장인데 1장은 퍼즐조각 하나가 없네요. 원하시면 퍼즐매트 같이 드려요.'
,'유아동','2023/01/30',79,8000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'block.jpg', '9999\99\99', 'blo');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'block.jpg', '9999\99\99', 'blo1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'파타고니아 레트로-x 자켓 유아 4t 유아아웃도어'
,'인기템 파타고니아 레트로x 자켓입니다.
동성로 매장에서 정가주고 구입했습니다.
많이 입히지 않고 보관을 많이해서 관리가 잘 되어있어요.
지난 가을에 입고 드라이하고 보관했어요.
레깅스 입히고 입히면 진짜 예뻐요.
전 그때 구하기 힘들어서 신세계매장도 여러번 갔던 기억이 있네요ㅎㅎㅎ
애들이 입으면 진짜 예쁩니다. 4t지만
2~3살 유아가 팔 접고 입으면 기장감이 약간 길게 느껴져서 예뻐요ㅎㅎ
득템해가세요ㅎㅎㅎ'
,'유아동','2023/02/01',116,65000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Patagonia.jpg', '9999\99\99', 'pata');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Patagonia.jpg', '9999\99\99', 'pata1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Patagonia.jpg', '9999\99\99', 'pata2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'유아신발 유아단화 140'
,'갈색 단화 판매합니다

사이즈는 140 입니다
슈퍼스타 130 신길때 예쁘게 신겼어요~

몇번 신지 않아서 상태 좋아요~'
,'유아동','2023/01/30',113,10000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zxcz.jpg', '9999\99\99', 'zxcz');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zxcz.jpg', '9999\99\99', 'zxcz1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'유아신발 유아운동화(반스)'
,'몇번 안 신었고
신발 안쪽에는 찍찍이가 있어서
신고 벗기기 좋아요^^

사이즈는 사진 참고해주세요^^'
,'유아동','2023/01/29',34,15000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'vans.jpg', '9999\99\99', 'vans');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'vans.jpg', '9999\99\99', 'vans1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'노스페이스 유아 패딩(110사이즈),유아 점퍼'
,'진핑크 오리털 패딩입니다.
네임택에 이름 안적었어요.
진핑크라 여자친구 입으면 예뻐요.
모자부분도 밴딩이되어서 쓰면 바람 안들어오고 따듯해요.
직거래원합니다.
교환,환불안되니 예민맘은 패스부탁드려요.'
,'유아동','2023/02/01',64,20000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'northface.jpg', '9999\99\99', 'tnf');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'northface.jpg', '9999\99\99', 'tnf1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'northface.jpg', '9999\99\99', 'tnf2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'벤츠 ML350 유아전동차 유아자동차'
,'중고제품 구매하여 몇번 타다가 판매합니다.
사진 첨부한 것처럼 얼룩있고 안보이는 부분에도
기스나 깨진 부분 있을수도 있습니다.
중고이다보니 사용감은 당연히 있으며 저렴한 가격에라도 괜찮으신 분들만 문의해주셨으면 합니다.
리모컨 있으나 건전지는 따로 넣어주셔야 하고
부피도 있고 무거워서 직거래만 가능합니다.
(사당롯데캐슬2차 놀이터 앞)'
,'유아동','2023/01/31',145,10000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'benz.jpg', '9999\99\99', 'benz');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'benz.jpg', '9999\99\99', 'benz1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'삼천리 유아 자전거. 유아차 자전거.'
,'2022년 초 당근구매.
아이가 싫어해서 보관만 했습니다.

수성구 파동, 수성못 근처 직거래'
,'유아동','2023/01/30',42,30000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, '3bal.jpg', '9999\99\99', '3bal');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, '3bal.jpg', '9999\99\99', '3bal1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, '3bal.jpg', '9999\99\99', '3bal2');

--------------------------------------------------------------------------------------------------------------
--의류

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'스톤아일랜드 티셔츠 size100 스톤아일랜드 롱슬리브 티셔츠 (봄.가을)',
'신세계백화점 구매 정품
비만으로 옷 작아요
와펜 지인줘서 없어요^^

천 헤짐 없어요
그래도 민감한분은 피해주세요

직장인이라 답이 늦을 수 있어요
양해부탁요

쿨거래 원해요'
,'의류','2023/01/31',163,70000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ston.jpg', '9999\99\99', 'ston');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ston.jpg', '9999\99\99', 'ston1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'칼하트x스투시 후드집업'
,'칼하트 스투시 콜라보 후드집업 팝니다 정품이구요
안감이 짱짱하고 디자인 예뻐요🥺 전체적으로 깨끗하고 보풀이나 큰 하자는 없어요!!️ 생활하자나 빛바램은 조금 있는데 제 눈엔 거슬리는 정도는 아니지만 예민하신 분들은 피해가셔용'
,'의류','2023/02/01',18,80000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'kst.jpg', '9999\99\99', 'kst');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'kst.jpg', '9999\99\99', 'kst1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'kst.jpg', '9999\99\99', 'kst2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'Acne 아크네 양털 후드 무스탕'
,'아크네 양털 후드 무스탕 자켓 34사이즈 입니다.
400만원대. 실착 5-6회 정도.

루즈핏이라 55-66 다 괜찮을 것 같아요.
색이 정말 예쁜데 잘 안담기네요. 약간 브라운 빛이도는 그레이 느낌이에요. 털 상태 좋고, 진짜 예뻐용!
여행갔을 때 샀는데 국내에서 이 디자인은 잘 못본 것 같아요.

살이 너무 쪄서.. 잠그면 좀 답답한 느낌이 있어서 손이 잘 안가서 당근해요. 늘 살빼고 입어야지 하지만.. 올해 또 못입고 보낼거 알기에...

*재택으로 당산계룡리슈빌1단지 앞 거래가는하며, 택배거래도 가능합니다.'
,'의류','2023/02/02',493,998000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'acne.jpg', '9999\99\99', 'acne');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'acne.jpg', '9999\99\99', 'acne1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'acne.jpg', '9999\99\99', 'acne2');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'acne.jpg', '9999\99\99', 'acne3');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'(48) 우영미 백로고 화이트'
,'우영미 백로고 화이트 48사이즈입니다.
세탁완료했구 상태 궁금하신점있으면 더 보여드릴수있습니다. 궁금하신점이나 네고등 많이 찔러봐주세요'
,'의류','2023/02/01',327,150000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wo.jpg', '9999\99\99', 'wo');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wo.jpg', '9999\99\99', 'wo1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'스타일난다 크롭 크롭탑 골지티 브이넥티'
,'데님 트레이닝복 위에도 이뻐요 배송가능합니다'
,'의류','2023/01/31',26,13000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'crop.jpg', '9999\99\99', 'crop1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'crop.jpg', '9999\99\99', 'crop');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'22-23 시즌 토트넘 손흥민 마킹 유니폼'
,'사놓고 보관만 하던 새상품입니다
토트넘 경기할때 경기장에서 산 정품입니다
사이즈는 S입니다'
,'의류','2023/02/01',186,150000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'son.jpg', '9999\99\99', 'son');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'son.jpg', '9999\99\99', 'son1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'스톤아일랜드 다비드TC패딩'
,'새제품 입니다 실착1회도 안하고 소장하다
이사준비로 정리합니다
내피 탈부착가능해요
105/XL'
,'의류','2023/01/29',241,930000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'stonp.jpg', '9999\99\99', 'stonp');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'stonp.jpg', '9999\99\99', 'stonp1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'stonp.jpg', '9999\99\99', 'stonp2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'아이앱스튜디오 하프 집 풀어버 라이트그레이 아노락L'
,'상태는 사진으로 보는것 같이 좋아요
사진 부탁하시면 더 보내드려요 연락주세요!'
,'의류','2023/01/30',156,152000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'iab.jpg', '9999\99\99', 'iab');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'iab.jpg', '9999\99\99', 'iab1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'아미 톤온톤 후드티 아쿠아 XL'
,'택도 안떼고 그대로 보관한 새상품 판매합니다~
강변역 근처 장소에서 직거래 가능하고 쿨거래시 택배비 포함합니다~
아주 싸게 올렸으니 에누리문의는 하지 말아주세요 ㅜ'
,'의류','2023/01/29',179,270000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ami.jpg', '9999\99\99', 'ami');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ami.jpg', '9999\99\99', 'ami1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ami.jpg', '9999\99\99', 'ami2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'지방시 여성 블레이저 자켓'
,'새상품
사이즈 36
구성품: 옷, 옷걸이
gs반값택배 or 서귀 1청사 직거래'
,'의류','2023/02/01',406,300000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'givenchy.jpg', '9999\99\99', 'givenchy');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'givenchy.jpg', '9999\99\99', 'givenchy1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'givenchy.jpg', '9999\99\99', 'givenchy2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'슈스톤 슈프림 스톤아일랜드 코듀로이 자켓 오렌지 95 사이즈'
,'(급처) 슈스톤 슈프림 스톤아일랜드 코듀로이 자켓 오렌지 95 사이즈 2회 착용 상품입니다. 구성품이 본품 외에 없기에 가격을 낮춰 판매합니다. 문의주세요.'
,'의류','2023/01/31',128,550000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'stonj.jpg', '9999\99\99', 'stonj');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'stonj.jpg', '9999\99\99', 'stonj1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'stonj.jpg', '9999\99\99', 'stonj2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'acne studio 아크네스튜디오 유광 패딩'
,'실착 2회 상품입니다
올해 유광패딩이 유행이라 구매했는데 애엄마한테는 너무 과한것같아서 내놓습니다 ㅠㅠ
뒷면에 로고포인트 예뻐요:)
사이즈 xs입니다.'
,'의류','2023/01/31',394,500000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'acnep.jpg', '9999\99\99', 'acnep');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'acnep.jpg', '9999\99\99', 'acnep1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'acnep.jpg', '9999\99\99', 'acnep2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'준지 엔틱실버 엠브로이더리 후드'
,'준지 엠브로이더리 후드 엔틱실버
고급진 엔틱실버 색감과 준지특유의 로고,
전면 프린팅 색감 조합 까지
정말 이쁜제품이며 완판되고
매물 잘 안뜨는 제품입니다

m사이즈 새상품

460000 -> 35 (쿨거래 30)'
,'의류','2023/02/02',107,300000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'juunj.jpg', '9999\99\99', 'juunj');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'juunj.jpg', '9999\99\99', 'juunj1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'juunj.jpg', '9999\99\99', 'juunj2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'새상품) 파타고니아 토렌쉘 우먼 여성 XS 화이트'
,'파타고니아 토렌쉘
우먼스 여성용
사이즈 XS
버치화이트
토렌쉘은 크게나오는 편 입니다'
,'의류','2023/01/30',24,200000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'patagoniaj.jpg', '9999\99\99', 'patagoniaj');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'patagoniaj.jpg', '9999\99\99', 'patagoniaj1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'구찌팔라스 트랙자켓'
,'XL 입니다
새상품입니다
착용샷은 다른 사이즈 입은 사진 ㅎㅎ'
,'의류','2023/02/02',1006,5200000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'gucci.jpg', '9999\99\99', 'gucci');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'gucci.jpg', '9999\99\99', 'gucci1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'gucci.jpg', '9999\99\99', 'gucci2');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'gucci.jpg', '9999\99\99', 'gucci3');


-----------------------------------------------------------------------------------------------------------------
--잡화
INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'*새상품*나이키 조던 245 조던로우 스모크그레이색상'
,'크림구매 조던 스모크그레이245사이즈 판매합니다 신으려구매하고 맨날슬리퍼신느라 안신을거같아 판매합니다. 리셀가는 계속오르니 구매하시고 가격오르면 되파셔도됩니다. 현재 크림에서구매시 42만원입니다'
,'잡화','2023/01/29',195,340000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'whejsz.jpg', '9999\99\66', 'whejsz');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'whejsz.jpg', '9999\99\66', 'whejsz1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'이지부스트350'
,'아코탭 다있어요 사용감있음
사이즈 255 풀박스'
,'잡화','2023/01/29',367,230000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlwlqn.jpg', '9999\99\66', 'dlwlqn');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlwlqn.jpg', '9999\99\66', 'dlwlqn1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'[Uk9,280] 구찌 라이톤 띠로고'
,'박스 및 인보이스 포함 풀구성품

세탁 맡기시면 좋은 컨디션으로 착용 가능합니다
복원이 힘든 터짐이나 찢어짐 같은 하자 일절 없습니다
직거래 영운동 삼영부속구이 앞
빠른 판매를 위하여 가격 낮추었습니다.
3통이내 쿨거래시 소정의 에눌 해드려요
스톤 검정색 교신 환영 (XL~)
연락주세요'
,'잡화','2023/01/29',213,300000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'fkdlxhs.jpg', '9999\99\66', 'fkdlxhs');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'fkdlxhs.jpg', '9999\99\66', 'fkdlxhs1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'22FW 슈프림 벤틸 캠프캡 슈프림캠프캡 슈프림모자 슈프림캡'
,'새상품 ( 원사이즈 )'
,'잡화','2023/01/30',185,230000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tbvmtbvm.jpg', '9999\99\66', 'tbvmtbvm');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tbvmtbvm.jpg', '9999\99\66', 'tbvmtbvm1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'CROCS 크록스 / 클래식 플랫폼 클로그 / 260 / W10 / M8 / 크록스 /'
,'크록스 Crocs
클래식 플랫폼 클로그 Classic Platform Clog

색상 : 블랙
사이즈 : 한국 260 / 미국 W10, M8

크록스 밑창이 얇으면 불편해서 두꺼운 것을 찾다가 미국에서 직구로 샀습니다.

한국에선 클래식 플랫폼 클로그가 260 이상은 판매하지 않는것으로 알고 있습니다.

제게는 사이즈가 작아서 판매 하려 합니다.
실내에서 실착 1회 하였습니다.
밑창 사진 보시다시피 마트 오프매장에서 누가 신어본 적 있는 신품보다도 깨끗합니다.

백석역 인근 직거래 가능합니다.'
,'잡화','2023/01/30',95,40000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'crocs.jpg', '9999\99\66', 'crocs');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'crocs.jpg', '9999\99\66', 'crocs1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'아크네스튜디오 acnestudios 머플러'
,'이제 이사준비하느라 집에있는 옷들 저렴하게 처분해요:-) 여러게하시면 에눌 해드릴게요!!'
,'잡화','2023/01/30',220,150000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ajvmffjdk.jpg', '9999\99\66', 'ajvmffjdk');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ajvmffjdk.jpg', '9999\99\66', 'ajvmffjdk1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'에르메스 테슬 로퍼 35.5'
,'에르메스 테슬 로퍼 사이즈 35.5
디자인, 소재, 컬러가 흔하지않고 유니크해요.
(정확한 사이즈 조언은 어려우니 충분히 검색하시고
고민후에 구매결정된분만 챗주세요.)

소재가 단단해서 구김이 잘 안생기고 좋아요.
앞코, 뒷굽 까임 전혀없고 전반적으로 상태좋아요.
박스, 더스트 없어요. 정품슈즈만 판매해요.

펑방지 예약금 10만원 있어요. 환불불가합니다.
직거래만 가능합니다. 택배거래 문의에 답하지않아요.

애눌문의 사절, 이미 판매글에 있는 내용과 관련된 질문에
답안드려요. 신중하게 구매결정하신분만 채팅주세요.
예의없는분과 거래안해요.'
,'잡화','2023/01/30',157,370000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'fhvjdpfm.jpg', '9999\99\66', 'fhvjdpfm');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'fhvjdpfm.jpg', '9999\99\66', 'fhvjdpfm1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'고야드 생루이 pm'
,'내부 외부 오염 하자없고 깨끗해요
구매택있고 더스트 있습니다
직거래 계약금 받습니다'
,'잡화','2023/01/30',115,31170000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rhdiemtod.jpg', '9999\99\66', 'rhdiemtod');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rhdiemtod.jpg', '9999\99\66', 'rhdiemtod1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'ROLEX 롤렉스 투톤 18K골드 시계 16013'
,'투톤 18K 골드 롤렉스 16013

질문이 있으면 메시지 주세요

73년

₩6,000,000!!!

(1월 21일) 이 시계를 마지막으로 할인해 드리겠습니다! 일주일 안에 안 팔리면 그냥 시계를 가지고 있을게요.'
,'잡화','2023/01/31',466,6000000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'fhffprtm.jpg', '9999\99\66', 'fhffprtm');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'fhffprtm.jpg', '9999\99\66', 'fhffprtm1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'프라다 사피아노 럭스 BN1786'
,'구매해서 1년 정도 잘 들고 다니고 그 후로는 충전재 넣어 더스트백에 보관했어요. 초기 모델이라 그 후로 나온 사피아노 모델보다 더 예쁘고 고급스러워요.

전체적으로는 각 무너짐 거의 없이 상태 좋은데 손잡이에 자연스러운 사용감 있고 바닥 모서리 닳음 있습니다. 사진과 상태 동일하니 참고 부탁드려요.'
,'잡화','2023/01/31',577,350000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tkvldksh.jpg', '9999\99\66', 'tkvldksh');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tkvldksh.jpg', '9999\99\66', 'tkvldksh1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'[275] 뉴발란스 992 x jjjjound 자운드 그레이 m992j2'
,'거래지역: 사당 강남 과천

판매제품명: 뉴발란스 992 x jjjjound 자운드 그레이 m992j2

사이즈: 275

상태 : GOAT택 포함한 풀구성품, 단 1회 잠깐 착용한 극미중고

가격 : 139(문자3통이하 거래시 운포)'
,'잡화','2023/01/31',419,1390000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sbqkfdm.jpg', '9999\99\66', 'sbqkfdm');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sbqkfdm.jpg', '9999\99\66', 'sbqkfdm1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'펜디머플러빅사이즈숄머플러겸용'
,'두툼하니좋아요
빅사이즈에요
190*37'
,'잡화','2023/01/31',242,150000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'vpselvps.jpg', '9999\99\66', 'vpselvps');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'vpselvps.jpg', '9999\99\66', 'vpselvps1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'커먼프로젝트 스니커즈 270'
,'대구 띠어리 매장에서 구매했습니다.
실착 10회 미만이며
구매 하고 세탁 안했습니다.
슈케어나 닦아 신으시면 거의 새것과 동일 합니다
270 사이즈 이며
쿨거래시 네고 가능합니다.'
,'잡화','2023/01/31',261,124000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zjajsvmfhwprxm.jpg', '9999\99\66', 'zjajsvmfhwprxm');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zjajsvmfhwprxm.jpg', '9999\99\66', 'zjajsvmfhwprxm1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'구찌로퍼 구찌홀스빗로퍼 남성로퍼 남성구두 명품로퍼 급처!275~280'
,'구찌로퍼 라인중 가장 예쁜 홀스빗로퍼 입니다.구매가는 100만원 초반대고 거의 신지 않아 약간의 사용감 제하고 컨디션 매우 좋습니다.급전 필요해서 아주 싸게올립니다.'
,'잡화','2023/02/01',370,450000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rnWlfhvj.jpg', '9999\99\66', 'rnWlfhvj');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rnWlfhvj.jpg', '9999\99\66', 'rnWlfhvj1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'[300] 나이키 x 오프화이트 덩크로우 파인 그린 / 흰초 덩크 로우 파인그린 판매'
,'[300] 나이키 x 오프화이트 덩크로우 파인 그린 / 흰초 덩크 로우 파인그린 판매'
,'잡화','2023/02/02',370,450000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'akwlakrtq.jpg', '9999\99\66', 'akwlakrtq');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'akwlakrtq.jpg', '9999\99\66', 'akwlakrtq1');


------------------------------------------------------------------------------------------------------------------
--뷰티 미용
INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'조르지오 아르마니 향수 / 프리베 베르 말라키트 오 드 퍼퓸 / 남자향수 여자향수'
,'새제품 (상자는 없어요)
정가 430000
사용기한 25년 5월
반값택배/호평동 직거래 가능

화장품 너무 많아서 처분 중
다른 거랑 같이 사면 할인해드려요

이건 안팔리면 제가 쓸 거임..'
,'뷰티 미용','2023/01/29',31,250000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'armani.jpg', '9999\99\77', 'armani');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'armani.jpg', '9999\99\77', 'armani1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'샤넬 립스틱 샤넬립스틱 샤넬립밤 립밤'
,'새제품입니다 정가48000원'
,'뷰티 미용','2023/01/29',130,34000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'chanel.jpg', '9999\99\77', 'chanel');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'chanel.jpg', '9999\99\77', 'chanel1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'24k 골드 순금 금 화장품 9종 화장품세트/기초세트/주름개선 미백/선물추천 기초화장품 에센스 세럼 크림'
,'24k 골드 순금 금 화장품 9종 화장품세트/기초세트/주름개선 미백/선물추천 기초화장품 에센스 세럼 크림

99.9% 24k 순금이 들어간 기초화장품세트에요~
피부전문가 닥터엠의원 김동현 원장과 공동 개발한 화장품으로 미백 및 주름개선 이중 기능성 인증완료된 화장품이에요~홈케어나 특별한 선물을 원하시는 분께 추천드려요~♥️
쇼핑백도 있어 선물용으로 추천드려요

*효능
-천연 한방성분이 함유되어 있어 피부 수분 공급
-24k 순금의 마이너스 이온이 피부 진정 및 탄력 유지

*토너 - 앰플 - 에센스 - 아이크림 - 에멀젼 - 크림
순으로 발라주면 되세요~

*구성품
토너 120ml
에멀젼 120ml
에센스 35ml
앰플 35ml
크림 50g
아이크림 30g
앰플 20ml * 3개'
,'뷰티 미용','2023/01/29',775,42000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, '24k.jpg', '9999\99\77', '24k');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, '24k.jpg', '9999\99\77', '24k1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'설화수.. 진설 기초화장품입니다'
,'설화수.. 진설 기초화장품입니다
현대백화점에서 구입했습니다
현대백화점가 ₩265,000원입니다
유효기간은 2025년11월08일입니다
싸게 내놓습니다
득템하세요~~'
,'뷰티 미용','2023/01/29',19,170000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sulwhasoo.jpg', '9999\99\77', 'sulwhasoo');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sulwhasoo.jpg', '9999\99\77', 'sulwhasoo1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'바디워시 테소리 도리엔테 바디케어(이탈리아 프리미엄 퍼퓸바디케어)'
,'테소리 도리엔테 바디케어 선물세트
테소리도리엔테 배쓰크림(바디워시) 500ml
샤워크림(바디워시) 250ml
바디크림 300ml
샤워볼, 펌프 디스펜서'
,'뷰티 미용','2023/01/30',10,30000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tesori.jpg', '9999\99\77', 'tesori1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tesori.jpg', '9999\99\77', 'tesori');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'딥디크 롬브로단로 edt 50ml(국문택 O, 상자 O)'
,'신세계에서 산 정품입니다
국문택, 상자 있습니다
잔량은 사진 확인해주세요!
구입 초반에 5번정도 쓰고 안썼습니다

광나루역 5호선에서 직거래 원합니다
개찰구 거래, 계좌이체 가능합니다'
,'뷰티 미용','2023/01/30',38,105000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'diptyque.jpg', '9999\99\77', 'diptyque');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'diptyque.jpg', '9999\99\77', 'diptyque1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'쥬네셀 화장품세트 줄기세포 화장품 (해외수출화장품)황우석 박사 고급 브랜드'
,'쥬네셀 화장품은 황우석 박사 줄기세포 화장품으로 해외수출만 하는 고급 브랜드 입니다.
2세트 선물 받아 한세트는 판매 합니다.
해외에서 60만원 하는 세트이고 35만원에 판매 합니다.2025년까지

구매하시면 마스크팩세트도 같이 드릴게요.

구성
에센스
에멀젼
리치크림
아이크림 등'
,'뷰티 미용','2023/01/30',24,350000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'junecell.jpg', '9999\99\77', 'junecell');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'junecell.jpg', '9999\99\77', 'junecell1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'샤넬 수분 크림 / 하이드라 / 이드라 뷰티 크림 / 샤넬 화장품 / 샤넬 뷰티 / 여성 수분크림'
,'샤넬 이드라 뷰티 크림 50g
수분크림 새상품입니다.
유통기한 ~2024.9월까지이고 쇼핑백 함께 드려요.

이매동 경비실 비대면 거래해요.
택배는 착불이나 택배비 함께주시면 택포로 가능합니다(반값택배도 가능).'
,'뷰티 미용','2023/01/30',178,82000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlemfk.jpg', '9999\99\77', 'dlemfk');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlemfk.jpg', '9999\99\77', 'dlemfk1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'Jo Malone 조말론 향수 라임바질앤만다린 100ml'
,'Jo Malone 조말론 향수 판매합니다
- 라임바질앤만다린 100ml (새제품 X)

구매한지 6개월 정도 되었으며
잔량은 첨부 사진으로 직접 확인해 주세요

* 박스 및 쇼핑백 포함 (사진 참조)
* 택배비 포함
* 직거래 시 광화문역/압구정역 가능'
,'뷰티 미용','2023/01/30',90,130000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'malone.jpg', '9999\99\77', 'malone');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'malone.jpg', '9999\99\77', 'malone1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'딥디크향수,딥디크더스트백향수케이스(새상품)셋트둘다드려요'
,'딥디크향수+더스트백향수케이스 (한번시향새상품)

딥디크 오드 뚜왈렛 필로시코스 향수입니다
우아한 향이며 자세한향은 검색부탁드려용
한번시향했으며 거의새재품이나 다름없습니다
13만원~24만원 이상 세트로 구매해야 받을수있는 향수 유리보호더스트백딥디크케이스도 같이 드려요 !
샘플크기 절때아니며 옆에 50ml향수 비교샷으로 올려놓앗습니다 한참 쓰는 용량이에요
휴대용으로 많이 구매하는 인기 향수 입니다'
,'뷰티 미용','2023/01/31',835,28800,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'elqelzm.jpg', '9999\99\77', 'elqelzm');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'elqelzm.jpg', '9999\99\77', 'elqelzm1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'새상품 조말론 jomalone 9ml 컬렉션 5개 세트 명품 향수'
,'봉투 +9ml 향수 5개 세트
english pear & freesia cologne 9ml, peony & blush suede 9ml, wood sage & sea salt cologne 9ml, blackberry & bay cologne 9ml & wild bluebell cologne 9ml

25년 3월까지 새상품'
,'뷰티 미용','2023/01/31',255,120000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'akffhswh.jpg', '9999\99\77', 'akffhswh');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'akffhswh.jpg', '9999\99\77', 'akffhswh1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'탬버린즈 소독제, 핸드크림 세트(핸드크림 추가)'
,'탬버린즈 새거 세트판매합니다.
손소독제, 핸드크림'
,'뷰티 미용','2023/02/01',25,20000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tamburins.jpg', '9999\99\77', 'tamburins');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tamburins.jpg', '9999\99\77', 'tamburins1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'입생롤랑 명품향수 입생로랑 ysl 입생 향수 리브르오브빠르펭 50 ml'
,'부산 롯데백화점 본점에서 산거 친구한테
선물 받았습니다
5/3 정도 남아있습니다
병이랑 너무 고급지고 이쁜데
직업상 향수를 안쓰게
되어서 판매합니다
상자 다같이 있어요

명륜역 동래역 교대역 가능
벽산아스타 가능'
,'뷰티 미용','2023/02/01',312,39000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ysl.jpg', '9999\99\77', 'ysl');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ysl.jpg', '9999\99\77', 'ysl1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'샤넬 누메로엉드 리바이탈라이징 리치 크림 화장품 50g, 샤넬 화장품, 명품화장품, 설선물, 화장품'
,'선물받은 샤넬 화장품이예요~
15일전쯤 받았는데
제가 샤넬이 사용안해서
판매해요^^
새상품이고 사진찍느라
박스에서 뒤쪽으로 꺼낸게
전부예요
샤넬 박스 종이가방 모두
그대로여서 선물도
가능하실 거예요^^'
,'뷰티 미용','2023/02/02',110,130000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dechanel.jpg', '9999\99\77', 'dechanel');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dechanel.jpg', '9999\99\77', 'dechanel1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'도루코 면도기 면도날 쉐이빙폼'
,'도루코 3D 모션
면도기 +면도날 11개 + 페이스7(민감성피부용 면도날) 4개 +쉐이빙폼 샘플6개

새상품 미개봉 사진 그대로/환불안됨'
,'뷰티 미용','2023/02/02',165,30000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dorco.jpg', '9999\99\77', 'dorco');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dorco.jpg', '9999\99\77', 'dorco1');


------------------------------------------------------------------------------------------------------------------
--취미 게임 음반
INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'멜킨 무게조절 덤벨 24kg 덤벨 누오덤벨'
,'한쪽 손잡이는 최근 신형으로 교체하였습니다.
혹시 모르니 쓰던 손잡이도 같이 드리겠습니다.
무게 조절 전부 잘 됩니다.
너무 잘 쓰다가 아깝지만 기변하게되어 팝니다.
연락 주세요!'
,'취미 게임 음반','2023/01/31',283,150000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dumbbell.jpg', '9999\99\88', 'dumbbell');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dumbbell.jpg', '9999\99\88', 'dumbbell1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'혁오 22 cd음반 판매합니다.'
,'소장용 구매 후 보관만 한 미개봉 상품 판매합니다.
직거래만 가능합니다. 문의 주세요.'
,'취미 게임 음반','2023/01/30',26,30000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'hyukoh.jpg', '9999\99\88', 'hyukoh');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'hyukoh.jpg', '9999\99\88', 'hyukoh1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'골프, 골프채, 골프채세트, 클리블랜드 아이언세트 판매합니다.'
,'클리블랜드 그라파이트 FLEX-R
4,5,6,7,8,9,P,S(S는 DRACO)
중고거래 특성상 교환, 환불, 반품 불가합니다.'
,'취미 게임 음반','2023/01/31',1424,130000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'golf.jpg', '9999\99\88', 'golf');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'golf.jpg', '9999\99\88', 'golf1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'golf.jpg', '9999\99\88', 'golf2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'엑스박스원 엑스박스 XBOXONE'
,'상태 양호한 탱크 엑스박스원 판매 합니다
아이들 좋아하는 마인크래프트, 마크던전스 모두 잘돌아가고 넷플릭스, 디즈니플러스도 잘 보고 있습니다. 유튜브, 인터넷에서 다운받은 동영상 시청까지 동영상머신만으로도 가성비 갑입니다
현 중고시세 3만원 상당 게임시디는 보너스로 드려요
라이즈 오브 더 툼 레이더는 한국어 풀더빙으로 3개 리부트 시리즈 중 제일 몰입감 있고 재미있게 한 게임입니다

*구성품 엑스박스원(500GB), 전원케이블, 컨트롤러, HDMI케이블, LAN케이블, 라이즈 오브 더 툼레이더
**네고불가'
,'취미 게임 음반','2023/01/29',954,65000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'xbox.jpg', '9999\99\88', 'xbox');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'xbox.jpg', '9999\99\88', 'xbox1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'xbox.jpg', '9999\99\88', 'xbox2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'Sony PS4 플스4 (8.50 버전) 플레이스테이션4 Playstation 4 + camera'
,'☆ 플스4 500GB 8.50 버전이고 판매합니다
시스템 소프트웨어 8.50

HDMI & 파워 케이블 + 플레이스테이션 카메라
듀얼쇼크컨트롤러 1개 + Playstation camera
구성품 중 번들 이어폰빼고 다 있습니다.
초기화 시켜놨구요

잘 아시는 분이 구입하셨으면 합니다.'
,'취미 게임 음반','2023/01/29',116,150000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'vmftm.jpg', '9999\99\88', 'vmftm');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'vmftm.jpg', '9999\99\88', 'vmftm1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'수채화용구 취미/입문용 세트(화구가방 포함)'
,'겨울을 맞아 수채화 배워보려고 샀는데 저는 소질이 없네요.^^;

2-3번 사용한 깨끗한 수채화 세트입니다. 취미로 수채화용구 필요하신 분 계시면 저렴하게 세트로 가져가세요~

- 산돌 아트백 4절 화구가방
- 신한 전문가용 수채물감 30색
(파레트에 있는 물감 한번 짜고 남은용량 많아요!)
- 미젤로 파레트+굳힌 물감
(번호 써놓아서 파레트의 물감 다 쓰시면 그대로 같은번호의 물감튜브 짜서 쓰시면 되세요)
- 화홍붓 8,10,12,16,20호
- 투명 플라스틱 붓 보관함
- 캔손 8절 수채패드 20매(새것)
- 물통'
,'취미 게임 음반','2023/01/31',32,50000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'canson.jpg', '9999\99\88', 'canson');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'canson.jpg', '9999\99\88', 'canson1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'canson.jpg', '9999\99\88', 'canson2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'Corona 코로나 취미용 기타 팝니다'
,'Corona 코로나 취미용 인테리어용 기타 팝니다

십년 전에 취미용으로 샀는데 거의 사용도 안하고 보관만 했습니다 오래 되어서 변색된 부분이 있긴 합니다 상세사진 확인해주세요

구매하시면 기타 커버도 같이 드립니다 다만 세탁을 하고 보니 커버 내부에 하자가 있네요 상세 사진 확인 부탁드립니다

기타줄도 오래 되어서 교체하셔야 할 것 같아요 정말 구매하고 한 번? 튕기기만 하고 계속 보관한 악기여서 좋은 주인 만났으면 좋겠습니다

기타 입문이시거나 취미용으로 쓰실 분이 가져가시면 좋을 것 같아요 아니면 인테리어용으로도 괜찮을 것 같습니다

직거래는 송파초 후문 앞에서 가능합니다'
,'취미 게임 음반','2023/01/30',491,50000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rlxk.jpg', '9999\99\88', 'rlxk');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rlxk.jpg', '9999\99\88', 'rlxk1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'닌텐도 스위치 oled +스플래툰+닌텐도 스포츠+드래곤볼+프로콘 등등 일괄판매'
,'닌텐도 스위치 oled 작년 9월 22일 스플래툰3 하고 싶어서 구매하였습니다
근데 저랑안맞더군요 닌텐도 스포츠만 25시간 했습니다
실사용 30시간정도 입니다
취직하게되어 할 시간이없어서 판매합니다

필름붙여서 있어요
사진에 보이는 프로콘 게임팩 액세사리 다 드리구요
계정에 DL게임 마리오카트8 뉴스노우브라더스 리틀나이트메어1,2 휴먼 폼 플랫
잔액6600 닌텐도 온라인 약 9개월 남음
있는데 닌텐도 앞으로 할생각없어서 전부양도드려요 닌텐도 어카운트 이메일변경하는데 충분히 잘 협조드려요 근데 변경하는 방법 잘몰라요 ;;

망우동 근처면 좋겠지만 중랑구내에서 직거래만할게요
감사합니다'
,'취미 게임 음반','2023/01/29',219,450000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'slsxpseh.jpg', '9999\99\88', 'slsxpseh');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'slsxpseh.jpg', '9999\99\88', 'slsxpseh1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'slsxpseh.jpg', '9999\99\88', 'slsxpseh2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'이고진 인클라인벤치, 아령 덤벨'
,'2020년 구매

1. 이고진 인클라인벤치 EX500 : 5만원
실사용 적으나 중고이기 때문에 약간 사용가 있을 수 있습니다.

2. 은성헬스빌 아령, 덤벨, 거치대 등 포함 : 3만원
조립식으로 무게조절 가능합니다. 구성품은 사진 참조해주세요.

3. 사진에 있는 폼롤러 드립니다.

모두 비대면 거래 (문 앞) 원하며 두개 동시에 쿨거래로 구매하시면 총 6만원에 드립니다.'
,'취미 게임 음반','2023/01/31',25,80000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'egojin.jpg', '9999\99\88', 'egojin');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'egojin.jpg', '9999\99\88', 'egojin1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'서태지와 아이들, 서태지 음반 CD 일괄 판매'
,'서울 선릉역 직거래 가능'
,'취미 게임 음반','2023/01/29',352,180000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tjxowl.jpg', '9999\99\88', 'tjxowl');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tjxowl.jpg', '9999\99\88', 'tjxowl1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'보드게임3종 (할리갈리컵스,코드팡,보드게임북)'
,'일괄 이만원에 팔아요
할리갈리 컵스는 몇번사용안햇어요
다른건 사용감 잇으니 예민하신분은 피해주세요
보드게임북은 정가22000원입니다
저렴히 가져가세용'
,'취미 게임 음반','2023/01/31',175,18000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qhemrpdla.jpg', '9999\99\88', 'qhemrpdla');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qhemrpdla.jpg', '9999\99\88', 'qhemrpdla1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qhemrpdla.jpg', '9999\99\88', 'qhemrpdla2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'SBD벨트(M사이즈) 팝니다'
,'22년8월 구매 상태좋습니다'
,'취미 게임 음반','2023/02/01',65,200000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sbd.jpg', '9999\99\88', 'sbd1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sbd.jpg', '9999\99\88', 'sbd');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'아디다스 엑스 고스티드 FG (손흥민축구화 260)엄프로축구화(새상품)도 같이드릴께요'
,'손흥민축구화 새제품
260사이즈입니다

엄브로 265 요건그냥같이 드릴께요'
,'취미 게임 음반','2023/01/30',1070,200000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'cnrrnghk.jpg', '9999\99\88', 'cnrrnghk');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'cnrrnghk.jpg', '9999\99\88', 'cnrrnghk1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'cnrrnghk.jpg', '9999\99\88', 'cnrrnghk2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'로지텍 G923 레이싱 휠, 쉬프터, 레이싱 시트 패키지'
,'ps5,ps4,pc 지원'
,'취미 게임 음반','2023/01/30',28,470000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qweqwe.jpg', '9999\99\88', 'qweqwe');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qweqwe.jpg', '9999\99\88', 'qweqwe1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'[중고] 배틀 마피아 게임 (최저가) | 아이들 게임 , 술 게임'
,'배틀 마피아 게임

☑ 1번 사용
☑ 건전지 포함

아이들과 함께 하거나 어른들 술 게임용으로도 아주 좋습니다!

부피가 있어서 직거래만 가능합니다!
직거래는 연신내역 근처에서 가능합니다!'
,'취미 게임 음반','2023/01/30',29,11000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'mafia.jpg', '9999\99\88', 'mafia');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'mafia.jpg', '9999\99\88', 'mafia1');


------------------------------------------------------------------------------------------------------------------
--도서
INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'[필수도서 일괄] 중학교 소설 읽기 소설책 일괄'
,'원가 8만원이고 새책입니다! 전국에 계신 국어선생님들이 만드신 책이라 중학교 올라 갈 때 국어 시험 보실 때 도움 많이 될 거예요! 일괄로만 넘기고 문고리 거래합니다!'
,'도서','2023/01/30',39,25000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wndgkrry.jpg', '9999\99\88', 'wndgkrry');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wndgkrry.jpg', '9999\99\88', 'wndgkrry1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'★한국 로맨스소설★주산지의꿈 작가 소설 4권(소장용/상태 최상)'
,'집에 더 이상 책 둘 데가 없어서 팝니다

"주산지의 꿈" 님의 로맨스 소설 4권입니다!
전부 서점에서 직접 구매한 소장용이구요,
딱 1번 읽고 책장에 고이 모셔두기만 해서 상태 완전 좋아요~ 이보다 더 좋을 수는 없을거라 자부합니다. 진심 새 책 컨디션

1. 헤리엇의 비밀 수첩 1~2권(완)
ㄴ서양풍 로판(로맨스 판타지) 소설, 18세기 배경. 백작가의 영애인 여주가 신분과 성별을 숨기고 소설을 씁니다. 작품 소재를 위해 미치광이 백작이라 불리는 남주의 저택에 하녀로 잠입하면서 일어나는 흥미진진한 내용이에요. 두 권으로 완결입니다!

2. 만지작 만지작
ㄴ로맨스인데 현대와 과거를 넘나드는 소설. 헤이그의 골동품점에서 발견한 회중시계로 인해 얽히게 된 여주와 남주. 사실 두 사람은 아주 먼 옛날, 고종황제 시대부터 이어져온 인연이었습니다. 한권짜리 단편인데도 추리해가는 재미도 있고 역사적 사실을 접목시킨 점이 인상적이었어요.

3. 사무치다
ㄴ동양풍 로판 소설. 정확한 시대배경은 잘 모르겠지만 읽다보면 삼국시대나 중국 청나라가 연상됩니다. 여주가 지형도를 훔치기 위해 남장을 하고 적진에 잠입해요. 거기서 적국의 황자인 남주와 만나게 되고, 둘은 금단의 사랑(?)에 빠지는.. 한권짜리이고 깔끔하게 딱 떨어지는 느낌.

4권 원가 36,000원 -> 판매가 19,000원
가격 더 안내려요~

환불 X / 직거래 화정, GS25 편의점 반값택배 가능(뽁뽁이 포장해서 보내드립니다!)'
,'도서','2023/01/31',80,19000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wntkswl.jpg', '9999\99\88', 'wntkswl');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wntkswl.jpg', '9999\99\88', 'wntkswl1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'웹툰 킹스메이커'
,'방문택배로 보내드려요
일반택배보다 1~2일 늦을수 있어요
택배무료 반품 네고안됌
3권 다드려요'
,'도서','2023/01/30',27,15000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zldtm.jpg', '9999\99\88', 'zldtm');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zldtm.jpg', '9999\99\88', 'zldtm1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'허영만 꼴 만화 관상 서적 만화책'
,'총 10권 셋트입니다.

사진과 같이 7 ,8,9 권, 신기원 관상학 은 미개봉
비닐 그대로.. 나머지는 1회 접지않고 깨끗하게
보았습니다.'
,'도서','2023/01/29',21,40000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'gjdud.jpg', '9999\99\88', 'gjdud');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'gjdud.jpg', '9999\99\88', 'gjdud1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'우리가 빛의 속도로 갈 수 없다면/ 김초엽 소설/ 소설책'
,'초반 한 10-20페이지 정도만 읽었던 책이라
책표지, 내부 깨끗하고 책 커버 찍힘이랑 물에 살짝 닿았었던 부분 외에는 하자 없습니다!
(물에 닿았던 부분도 얼룩없고 살짝 구부러진 정도)

인천대입구역 근처까지 직거래 가능합니다:)'
,'도서','2023/01/29',21,40000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dnqlc.jpg', '9999\99\88', 'dnqlc');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dnqlc.jpg', '9999\99\88', 'dnqlc1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'아몬드 소설책'
,'원가 12000원
재밌는 소설책 입니다.'
,'도서','2023/01/30',25,3000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dkahsem.jpg', '9999\99\88', 'dkahsem');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dkahsem.jpg', '9999\99\88', 'dkahsem1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'너의 이름은 만화책1~3권,소설'
,'총 4권 15000원에 팝니다
상태 좋아요

문고리거래
환불불가'
,'도서','2023/01/31',184,15000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlfmadms.jpg', '9999\99\88', 'dlfmadms');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlfmadms.jpg', '9999\99\88', 'dlfmadms1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'[새책] 미중전쟁 김진명 장편소설 2권'
,'새책입니다'
,'도서','2023/01/31',50,18000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'alwnd.jpg', '9999\99\88', 'alwnd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'alwnd.jpg', '9999\99\88', 'alwnd1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'너의 췌장을 먹고 싶어 오디오북+신장판 소설+만화세트'
,'너의 췌장을 먹고 싶어 오디오북+신장판 소설+만화 상,하권 박스세트

한 번도 안읽은 책이라서 깨끗합니다.'
,'도서','2023/02/01',40,27000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'cnpwkd.jpg', '9999\99\88', 'cnpwkd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'cnpwkd.jpg', '9999\99\88', 'cnpwkd1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'[중고도서] 조커와 나/김중미 소설집'
,'상태 좋고 직거래 원합니다.
직거래 장소: 은행사거리'
,'도서','2023/01/31',2,3000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'whzj.jpg', '9999\99\88', 'whzj');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'whzj.jpg', '9999\99\88', 'whzj1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'개미 소설'
,'상태 깨끗해요'
,'도서','2023/01/30',2,15000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'roal.jpg', '9999\99\88', 'roal');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'roal.jpg', '9999\99\88', 'roal1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'한국사 문제집(별별한국사심화 상,하/생강국사시리즈/생강한국사시리즈) *가격 본문확인'
,'책 모두 사놓고 한번도 푼 적 없습니다.
공부 안 할 것 같아서 팔아요..

1. 큰별쌤 최태성의 별별한국사 한국사 능력검정시험 심화(2022 시험 대비) 상,하 세트 25000원

2. 생강 국사 시리즈 3권 35000원

3. 생강 한국사 시리즈 3권 35000원'
,'도서','2023/01/30',11,35000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'gksrnrtk.jpg', '9999\99\88', 'gksrnrtk');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'gksrnrtk.jpg', '9999\99\88', 'gksrnrtk1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'에듀윌 전기기기-전기기사,전기공사기사,전기직'
,'23,000->️11,500

완전 새제품 입니다

직거래시 용문초등학교 앞에서 가능합니다
택배 시 착불로
편의점 반값택배,우체국 택배 가능합니다'
,'도서','2023/01/30',9,11500,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wjsrl.jpg', '9999\99\88', 'wjsrl');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wjsrl.jpg', '9999\99\88', 'wjsrl1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'만화로 보는 삼국지'
,'만화로 보는 삼국지 3권세트 판매합니다
책 상태 깨끗해요'
,'도서','2023/01/31',59,4000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tkarnrwl.jpg', '9999\99\88', 'tkarnrwl');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tkarnrwl.jpg', '9999\99\88', 'tkarnrwl1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'슬램덩크 만화책 1~19권 + 슬램덩크 완전판 3권'
,'슬램덩크 만화책 1~19권과 완전판 3화 팔고 있고 17.18권은 없습니다. 권당 3000원에 팔고 있습니다.
상태는 먼지 쌓인거 빼고는 깨끗합니다.'
,'도서','2023/01/30',230,3000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tmffoaejdzm.jpg', '9999\99\88', 'tmffoaejdzm');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tmffoaejdzm.jpg', '9999\99\88', 'tmffoaejdzm1');



------------------------------------------------------------------------------------------------------------------
--중고차
INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'현대 그랜저 HG HG300 GDI 익스클루시브'
,'1,290만원 ⸱ 15년식 ⸱ 7.9만km

장인어르신께서 새차로 사셔서 이용하셨구요, 
주로 출퇴근용으로만 이용하셨습니다.
이번에 차를 바꾸게 되셔서 급하게 내놓습니다.
차량이 아주 깨끗합니다.  
1.27 중고차 딜러분 점검결과
휠스크래치 3곳 있고 앞타이어 2개 교체필요하고,
외관 도색 2곳 정도 필요하다고 합니다.
차량보시고.. 가격조정 가능하니까 연락주세요.
참고로 차량은 포천에 있습니다.
감사합니다.^^'
,'중고차','2023/01/31',998,12900000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Grandeur.jpg', '9999\99\88', 'Grandeur');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Grandeur.jpg', '9999\99\88', 'Grandeur1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'Grandeur.jpg', '9999\99\88', 'Grandeur2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'벤츠 GLB 클래스 X247 GLB250 4Matic'
,'5,200만원 ⸱ 21년식 ⸱ 2.1만km

21년4월출고 벤츠GLB250 차량입니다.
거의 출퇴근용으로 썻구요. 
세로그릴변경
뒷자석 송풍구 추가시공
7인승 뒷자석 200만원주고 추가한차량입니다.
개인적으로 한번씩 7인승이 너무 유용하게 쓰엿던 차량입니다.
트렁크에서 케리어 꺼내다가 작은 찍힘.
왼쪽 오른쪽 휠 찍힘 기스.
무사고 현금차량입니다.
실내는 바닥매트 의자커버 트렁크매트 출고당일부터 사용하여서 깨끗합니다.
세차관리는 손세차로 본네트부터 타이어광택까지 꾸준히 관리해왔습니다'
,'중고차','2023/01/30',1054,52000000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'GLB250.jpg', '9999\99\88', 'GLB250');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'GLB250.jpg', '9999\99\88', 'GLB2501');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'GLB250.jpg', '9999\99\88', 'GLB2502');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'테슬라 모델 3 전기(50kWh) RWD 스탠다드 레인지 플러스'
,'3,900만원 ⸱ 20년식 ⸱ 5만km

테슬라 모델3 스탠다드 2020년 6월
▶ 차량설명
- 주행거리 : 50,000km
- 구입일자 : 2020년 6월 23일 신차구입
- 차량색 : 외부 화이트, 내부 블랙
- 사고유뮤 : 무사고
- 관리상태 : 기계세차X
- 내/외관 : 일부 휠기스외 양호
 
▶ 차량 구입 시 추가로 장착한 옵션이나 튜닝
- 레인보우 i90 썬팅(전/후/측면)
- 트렁크 천장/마닥 등 전체매트부착
- 무선핸드폰 충전
- 블랙박스
- 대쉬보드 셀프 카본랩핑
- 문짝 테슬라 웰컴등, PPF
- 3D 매트(순정 새매트도 보유)
- 하이패스 등
 
▶차주정보
- 구입방법 : 현금
- 판매이유 : 신차구매
- 운행용도 : 출퇴근용
 
▶ 사고나 수리 내역
- 주차시 우측휀더까짐(사진참조) 부분도장 완료
 
▶ 차량 확인이 가능한 지역
- 성북구, 송파구'
,'중고차','2023/01/30',697,39000000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tesla.jpg', '9999\99\88', 'tesla');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tesla.jpg', '9999\99\88', 'tesla1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tesla.jpg', '9999\99\88', 'tesla2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'현대 그랜드 스타렉스 TQ 12인승(디젤 2.5) 왜건 디럭스'
,'380만원 ⸱ 09년식 ⸱ 14만km

2009년식 그랜드 스타렉스 판매합니다.
외관이 깨끗하진 않지만 부식도없고
꾸준히 관리한 차량입니다.
사고이력은 조금 있지만
큰 사고는 없습니다.
시세 알아보고 저렴히 올렸습니다.'
,'중고차','2023/01/28',629,3800000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'starex.jpg', '9999\99\88', 'starex');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'starex.jpg', '9999\99\88', 'starex1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'starex.jpg', '9999\99\88', 'starex2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'미니 쿠퍼 Ⅲ F56/F55 5DR 1.5 (136마력)'
,'3,200만원 ⸱ 21년식 ⸱ 3370km

하만카돈스피커,비부링교체,사이드스커틀램프,스포츠안테나,블랙유광휠도색,풀코딩,전조등PPF,디테일세차,고급유주유,안드오토,애플카플레이무선
마트,아이등원용,보험이력무(완무)'
,'중고차','2023/02/01',1498,32000000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'mini.jpg', '9999\99\88', 'mini');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'mini.jpg', '9999\99\88', 'mini1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'르노코리아 QM6 HZG 5인승(디젤 2.0) FWD RE 시그니처'
,'1,700만원 ⸱ 17년식 ⸱ 3.4만km

개인 직거래 
1인 여성 운전자 출퇴근용 차량
소유자 변경 없음
연식에 비해 킬로수 짧음
완전무사고 보험이력 없음
외부 내부 깨끗 
수리할곳 없음

신차 구매후 유리막코팅 르노룩 으로 변경하여 일반 QM6 보다 더 예쁜 차량입니다
사진 보시고 궁금하신거 연락주세요'
,'중고차','2023/02/02',385,17000000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qm6.jpg', '9999\99\88', 'qm6');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qm6.jpg', '9999\99\88', 'qm61');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'르노코리아 SM6 LFD 1.5 dCi'
,'700만원 ⸱ 16년식 ⸱ 8.6만km

SM6 16년형 6월 년식입니다 
1.5디젤 이고 고속도로 연비 최강입니다.
100키로 정속주행시 25~27사이 나옵니다.
16년식 디젤 썬룹 제외 풀옵입니다.
사고는 3번 발생했으나, 수리하고 아무이상
없이 잘운행하고 있습니다.
2021년이 마지막 수리이고 2년동안 특이사항 없이 잘 타고 다녔습니다. 와이프 운전미숙으로
휀더등 살짝 기사가 있고,
승차감 때문에 16인치 휠로 변경 하였고
트레드 짱짱합니다.'
,'중고차','2023/01/30',1402,7000000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sm6.jpg', '9999\99\66', 'sm6');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'sm6.jpg', '9999\99\66', 'sm61');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'볼보 S80 2세대 D2'
,'1,100만원 ⸱ 15년식 ⸱ 12만km

15년 볼보 s80 d2 디젤 입니다
연비 좋고 엔진 미션 상태 정말 좋습니다
누유 없고 하체 잡소리 하나도 없음
보기 드문 실내 베이지 시트 최고사양 등급입니다. 
뼈대사고 없는 외판만 교환한 차량입니다. (성능지 보유 무사고)'
,'중고차','2023/01/30',818,11000000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 's80.jpg', '9999\99\66', 's80');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 's80.jpg', '9999\99\66', 's801');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'폭스바겐 뉴 비틀 9C/1Y 2.0 Cabriolet'
,'1,400만원 ⸱ 09년식 ⸱ 4.5만km

2009년식 뉴비틀 카브리올레입니다.
가장 인기 많은 베이지 색상에 베이지 시트입니다.
운전석 시트만 사용감 조금 있고 나머지는 거의 사용하지 않아 깨끗합니다.
후방카메라 외엔 별다른 튜닝을 하지 않아 순정 상태 그대로 입니다.
(+구매시 윈드 디플렉터, 탑커버도 같이 드립니다)

보험사고 전혀없으며, 이전 보험 이력도 없습니다.
연식 대비 정말 짧은 키로수에 차량 컨디션도 좋습니다.
주기적으로 차량 점검받으면서 관리해줬습니다.

정비내역
21.08 타이어 교체
22.04 엔진오일 교체(37,000km), 에어, 에어컨 필터 교체
22.06 산소센서 교체
22.10.02 써머스텟, 냉각수센서 교체
22.11 등속조인트 교체(앞쪽)

생활기스는 있습니다.

평소 출퇴근용으로 타고 다녀 운행거리가 짧습니다.
정말 아끼던 차지만 개인적인 사정이 생겨 판매를 하게되었습니다.
금액은 네고 가능합니다.(터무니 없는 네고 거절합니다.)

+현재 경고등 점등되어 수리예정중에 있으나 수리 전에 구매하시면 수리비용 빼고 드립니다.(이후 수리하고 사셔도 무관)'
,'중고차','2023/01/30',467,14000000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qlxmf.jpg', '9999\99\66', 'qlxmf');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qlxmf.jpg', '9999\99\66', 'qlxmf1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'현대 NF 쏘나타 트랜스폼 NF N20 트랜스폼 기본'
,'290만원 ⸱ 08년식 ⸱ 9.0만km

22년 7월에 자동차 기능종합진단 받은 내역 있습니다'
,'중고차','2023/01/28',562,2900000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'thskxk.jpg', '9999\99\66', 'thskxk');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'thskxk.jpg', '9999\99\66', 'thskxk1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'르노코리아 트위지 2인승(6.1 KWh) Intens'
,'250만원 ⸱ 19년식 ⸱ 8000km

2019 트위지

[용도]
동네 슈퍼용 
현재 주행거리 8301
 (소량 증가 할수 있음)

[튜닝내용]
전면선팅
2채널 블랙박스(앰블럼속에 깔끔하게 매립)
후방카메라
이군젠더(완속충전기 사용어뎁터)
프리미엄 창문 + 고무링 작업
서스펜션 스프링 작업
생활기스외 특이사항 없고 트위지 비상등 버튼 수리비(5-6만) 감가하여 가격 설정했습니다
가까운 거리에 이만한 차 없어요
차보다는 안전한 오토바이를 탄다라고 생각하셔야하고 보험은 자동차 보험으로 진행해야합니다'
,'중고차','2023/01/28',562,2900000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'xmdnlwl.jpg', '9999\99\66', 'xmdnlwl');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'xmdnlwl.jpg', '9999\99\66', 'xmdnlwl1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'기아 올 뉴 모닝 TA 1.0 카파 스마트'
,'320만원 ⸱ 13년식 ⸱ 12만km

13년식 쥐색 올뉴모닝입니다
타이어괜찮고 잘나가고 잘섭니다
현재까지 계속 타고다녀서 타시기에 좋으실겁니다
저렴하게 320만원에 판매합니다
12만키로에서 소폭 증가할수있습니다
네비게이션 있지만 후방카메라 없습니다
맘에드시는분 연락주세요'
,'중고차','2023/01/28',1433,3200000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ahsld.jpg', '9999\99\66', 'ahsld');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ahsld.jpg', '9999\99\66', 'ahsld1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'벤츠 E 클래스 W213 E220 d 4Matic 익스클루시브'
,'6,650만원 ⸱ 22년식 ⸱ 8977km

개인이며, 출퇴근용도로 사용한 차량 입니다. 전기차를 추가로 구입 하면서 전기차 한대로도 가능할것 같아서 내놓습니다.
22년 1월 20일에 출고하였으며, 무사고 차량이며, 차량 상태는 신차급 상태 그대로 새차 같은 상태입니다. 
집(아파트)과 회사 모두 실내에 주차를 했습니다. 
주행거리는 8,970키로 입니다.
차량 색상은 화이트, 내부는 블랙입니다.

선팅은 글래스틴트 레이니블루 전면 25, 측후면 10으로 시공 되어 있으며, 시인성 좋구요. 살짝 푸른끼가 있어서 하얀색과 정말 잘어울리고 이쁩니다. ^^

22년식 e클래스 차량으로 풍부한 옵션이 큰장점 입니다
선루프, 통풍시트, 열선시트, 핸들열선, 전동시트, 어뎁티브스마트크루즈컨크롤, 부메스터서라운드시스템, 350도서라운드뷰, 전동트렁크, 엠비언트라이트, 12.3인치 고해상도계기판 및센터디스플레이, 헤드업디스플레이, 반자율주행, 자동주차파킹파일럿, 사각지대어시스트, 애플카플레이/안드로이드오토지원, LTE모듈, 추돌방지시스템, 차선이탈경보, 하이패스, LED헤드램프, 공기압센서 등의 왠만한 옵션은 모두 포함 되어 있습니다.
그리고 다른 e220d 차량과 차이점이 있는 부분으로 E클래스 450에만 장착되는 에어바디콘트롤(에어서스펜션)이 옵션으로 장착되어 있습니다. 서스펜션을 언제든지 올렸다 내렸다 할수 있으며, 고속주행과 저속주행 모두 안락한 승차감이 정말 일품입니다. 코일서스펜션이 장착된 차량과는 큰차이가 있습니다.
또한 추가적으로 100만원 상당의 엠비언트 라이트가 장착된 부메스터 3D트워터와  송풍구가 추가 장착되어 있으며, 그외에도 여러 기타 추가 옵션들이 장착 되어있습니다.

비흡연자 입니다.
강남구 일원동 입니다.
차량 보시고, 쿨거래시 가격 조정도 가능 하시니 편하게 연락 주세요.
감사합니다.'
,'중고차','2023/01/31',1110,66500000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'roqlTka.jpg', '9999\99\66', 'roqlTka');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'roqlTka.jpg', '9999\99\66', 'roqlTka1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'roqlTka.jpg', '9999\99\66', 'roqlTka2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'현대 아반떼 MD M16 GDi 모던'
,'515만원 ⸱ 13년식 ⸱ 13만km

소개
교체 및 부품 수리 이력

소모품 
(22년 9월)
1. 엔진오일(코팅제 포함) 
2. 에어필터 
3. 오일필터
4. 에어컨 필터
5. 신품 점화 코일 4개 교체
6. 순정 점화 플러그 4개 교체
7. 브레이크 부동액 교체
8. 신품 전후 브레이크 패드 교체
9. 신품 배터리 교체

(22년 12월)
1. 전후 타이어 모두 금호 타이어 신품으로 교체

수리 
(22년 9월)
1. 신품 프론트 로어암 교체
2. 순정 핸들 버튼 및 스프링 교체
3. 신품 전후 브레이크 디스크 교체
4. 신품 캐니스터 교체
5. 혼 교체 (경적)

8월 공임나라 유료점검시 위 교체 항목 외 문제없음 확인
9월 블루핸즈 유료점검시 위 교체 항목 외 문제없음 확인

앞범퍼 찢어짐 확인해두세요. '
,'중고차','2023/01/31',1204,5150000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dkqkddl.jpg', '9999\99\66', 'dkqkddl');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dkqkddl.jpg', '9999\99\66', 'dkqkddl1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'KG 쌍용 베리 뉴 티볼리 X150 5인승(가솔린 1.5) 2WD V3'
,'1,810만원 ⸱ 21년식 ⸱ 1.4만km

저공해 차량 (공영주차장 주차 시 50% 감면혜택)
년식 대비 상당히 짧은 주행거리
앞유리 코팅처리 되어있음
외부.내부 모두 깨끗'
,'중고차','2023/02/01',616,18100000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'xlqhffl.jpg', '9999\99\66', 'xlqhffl');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'xlqhffl.jpg', '9999\99\66', 'xlqhffl1');


------------------------------------------------------------------------------------------------------------------
--가공식품
INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'더미식 장인라면 단백한맛4봉+ 얼큰한맛 4봉(총8봉) 라면 새상품'
,'더미식 장인라면 단백한맛4봉, 얼큰한맛 4봉
총 8봉 새상품입니다.

각 유통기한은 23년 6월 19일/6월 11일입니다.

첨부사진 확인해주세요.

(4봉만 원하시는분은 4천원에 판매할게요.)'
,'가공식품','2023/01/28',63,6000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'altlr.jpg', '9999\99\66', 'altlr');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'altlr.jpg', '9999\99\66', 'altlr1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'포켓몬빵 6개 일괄로 저렴히 판매나 띠부씰로 교환받습니다. 포켓몬 포켓몬빵 띠부씰'
,'스티커 포함된 개봉하지 않은 미개봉 새제품 그대로 판매합니다.

냉장보관중입니다.

미개봉 새제품 포켓몬빵 현금 거래로 가격은 6개 일괄 11,000원에 드립니다.

띠부씰 교환 시 이미지의 띠부씰로 11장 받습니다.

할로윈 띠부씰, 호빵 띠부씰 1장은 2장으로 치겠습니다.

러블리 띠부씰은 1장당 2.5장으로 칩니다.

가치 높은 일반 띠부씰로 교환시에는 비율 조정 가능하니 채팅주셔요.

현금이랑 띠부씰 섞어서 구매시에는 띠부씰 1장당 1,000원으로 계산해서 차액주시면 됩니다.

※ 상태 좋은 띠부씰만 교환 받습니다. (뗀 씰X, 찢어진 씰X, 구겨진 씰X, 얼룩있는 씰X 손톱자국 있는 씰X)'
,'가공식품','2023/01/28',9,11000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'vhzptahsQKd.jpg', '9999\99\66', 'vhzptahsQKd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'vhzptahsQKd.jpg', '9999\99\66', 'vhzptahsQKd1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'빙빙 과자 추억의과자'
,'아이스크림모양이라 아이들이 엄청좋아해요
6상자에 만원입니다'
,'가공식품','2023/01/28',68,10000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qldqld.jpg', '9999\99\66', 'qldqld');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qldqld.jpg', '9999\99\66', 'qldqld1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'과자 몽땅 다드려요 !'
,'과자 전부 일괄 드려요
유통기간 넉넉 합니다 !'
,'가공식품','2023/01/28',91,26000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rhkwkk.jpg', '9999\99\66', 'rhkwkk');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rhkwkk.jpg', '9999\99\66', 'rhkwkk1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'식사대용식품. 체중조절용식품'
,'세가지 다 맛있고 영양분도 고르게 들어있어서 바쁠 때 식사대용으로 먹기도 좋고 다이어트용으로 먹기도 좋아요. 너무 많이 사놓아서 판매해요.
평 좋은 상품들이고 맛도 보장합니다!!

한개씩 판매 안하기도하고 배송비도 부담스러운데 드셔보시고 주문하는 것도 괜찮을 것 같아요.
다 사이트가 다른데 섞어서 구매할 수 있는 것도 장점이겠네요.

2개 이상부터 판매합니다.

1. 고단고식흑임자
7개 28,000원에 구매했고 4개 있음
>> 개단 3천원에 판매합니다

2. 잔소리
5개 18,900원에 구매했고 6개 있음
>> 개당 3천원에 판매합니다

3. 마이너스쉐이크 초코프로틴
7개 35,000원에 구매했고 6개 있음
>> 개당 4천원에 판매합니다'
,'가공식품','2023/01/29',483,3000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wksthfl.jpg', '9999\99\66', 'wksthfl');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wksthfl.jpg', '9999\99\66', 'wksthfl1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'아이들간식 어른들술안주 동결식품팔아요'
,'개당3000원'
,'가공식품','2023/01/29',89,3000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ggga.jpg', '9999\99\66', 'ggga');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ggga.jpg', '9999\99\66', 'ggga1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'스팸 복합 100호 선물세트(카놀라유, 스팸 소중대) 판매'
,'안녕하세요.
스팸 복합 100호 선물세트 33,000원에 판매합니다.
구성품은 아래와 같습니다.
카놀라유 500mL 2개
스팸 120g 2개
스팸 200g 8개
스팸 340g 2개
박스 필요 없으신 분들은 제가 처리하고 내용물만 드리는 것도 가능합니다.
유통기한은 사진과 같습니다.
계산동에서 거래합니다.
감사합니다.'
,'가공식품','2023/01/29',162,33000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'spam.jpg', '9999\99\66', 'spam');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'spam.jpg', '9999\99\66', 'spam1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'(식품.참치)미개봉)동원참치 친 100호 셋트'
,'동원참치 친 100호 셋트 12개입
유통기한 2029년9월7일
이번 명절에 선문 받은건데
먹을 자신이 없어서 판매합니다
상품구성은 사진과 동일합니다

가능하면 비대면거래로 계좌거래하고 원하시는날 하안주공 7단지 705동 아파트 1층 경비실옆 택배보관소에 상품 놓아두는식으로 거래원합니다

평일 직거래는 6시이후 하안사거리 뉴코아아울렛 근방에서 거래가능합니다 낮에는 일관련 답장이 조금 늦을수있으니 양해부탁드릴께요
주말에는 원할한거래 가능합니다'
,'가공식품','2023/01/29',131,23000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tuna.jpg', '9999\99\66', 'tuna');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tuna.jpg', '9999\99\66', 'tuna1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'닭가슴살 33 +닭도그3개 +생닭가슴살 1'
,'한끼통살 되게 맛있죠 ㅎ 안 퍽퍽하고 맛도 다양
하나 2200원 정도 해요
전부 1500씩 계산 하고도 서비스 4 + 닭도그3

핵불닭 3
핫양념 7
스리라차마요1
데리야끼3
허니소이 4
갈릭 3
하이트머쉬룸 5
허니페퍼 머스터드1
슬라이스스팀 데리야끼 1
잠백이 불족발 1
흑마늘3
유통기한 2023.8

닭도그3
하림 생닭 가슴살 1

1500으로 계산해서 30개
1500*30 = ***-****-**** 게 닭도그 3개 생닭1개는 덤이에요~


잠백이 닭 4개만 유통기한 3.20 까지에요
받자마자 전부 냉동해서 상관 없어요'
,'가공식품','2023/01/30',166,45000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'aktdlTrpTek.jpg', '9999\99\66', 'aktdlTrpTek');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'aktdlTrpTek.jpg', '9999\99\66', 'aktdlTrpTek1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'소고기무국+소고기국밥'
,'오뚜기 소고기무국+소고기국밥.
2봉에 5000원.
새제품.
기한/사진참조.'
,'가공식품','2023/01/31',165,5000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'eowjstlr.jpg', '9999\99\66', 'eowjstlr');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'eowjstlr.jpg', '9999\99\66', 'eowjstlr1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'쇠고기(소고기) 육포'
,'개당 만원입니다!!
(인터넷 보니까 보통 150g에 15000원 하네요.)
일괄하시면 19000원이에요~~'
,'가공식품','2023/01/31',191,10000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'beefjerky.jpg', '9999\99\66', 'beefjerky');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'beefjerky.jpg', '9999\99\66', 'beefjerky1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'햇반 210g 11개 + 오뚜기밥 210g 2개 (즉석밥 총13개)'
,'햇반 210g 11개 + 오뚜기밥 210g 2개.
(즉석밥 총13개) 일괄 입니다.

햇반 / 유통기한 23년 9월 10일.
오뚜기밥 / 유통기한 23년 8월 24일.

네고문의는 사양하며,
미개봉 새것이지만, 중고거래 특성상 반품환불 안되며,

직거래는 서울 도봉구 방학1동
생잇들 어린이공원 놀이터 앞  근처입니다.

근처동네에서 대중교통으로 오신다면,
방학역 1번출구쪽이나
방학북부역 버스정류장,
오봉초등학교 버스정류장 등이 가까우며,
위의 장소 등에서도 거래가능합니다.'
,'가공식품','2023/01/31',151,11000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'gotqks.jpg', '9999\99\66', 'gotqks');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'gotqks.jpg', '9999\99\66', 'gotqks1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'권여사 하동김 하동녹차명란김 36봉 자연향기 기프트세트 선물세트 아이유 명란김 김 김세트'
,'새상품 박스포장그대로있어요
36봉 들어있어요
아이유 명란김으로 품절대란이었죠
선물하시기도 좋을거예요

제발제발제발 아래글 꼭 읽어봐주시고 문의주세요

개인체형이달라서 사이즈 확답못드리는점 양해부탁드립니다
사진 및 설명글 다 올렸는데 보지도 않고
무조건 만나서 다른 소리 하실분들
시간낭비 체력낭비 하지 말아주시기 바랍니다~~~~~~~~~~~~~~~~~!!!
실사 등등 사진 및 상품설명
제발제발제발 꼭 확인해주세요'
,'가공식품','2023/02/01',171,19000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rnjsdutk.jpg', '9999\99\66', 'rnjsdutk');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rnjsdutk.jpg', '9999\99\66', 'rnjsdutk1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'사조식품 설 명절 스페샬셋트 젤 큰사이즈~'
,'사조 설 명절 선물셋트~ 구성품은젤 큰 사이즈~생각보다 큰사이즈 알짜구성 입니다 시중가보다 마니 저렴하게 드려요 식용유 1개는 얼어 있네요~~교환 환불불가입니다 동의대 지하철역7번출구 거래가능합니다'
,'가공식품','2023/02/01',245,50000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dhkdnd.jpg', '9999\99\66', 'dhkdnd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dhkdnd.jpg', '9999\99\66', 'dhkdnd1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'코주부 프리미엄 육포 선물세트400g'
,'선물받았는데 먹을사람이 없어서 팝니다
브랜드 유명한 코주부 제품이고요
쿠팡가 47900원
인터넷최저가 6만원초반이네요(프리미엄)

어제 선물받은거라 유통기한 넉넉하구요
백포장까지 되어있어서 픽업후 바로 선물용으로 사용하셔도됩니다

2세트중1세트 남았어요
가정동
챗주세요'
,'가공식품','2023/02/01',272,40000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zhwnqndbr.jpg', '9999\99\66', 'zhwnqndbr');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zhwnqndbr.jpg', '9999\99\66', 'zhwnqndbr1');


------------------------------------------------------------------------------------------------------------------
--반려동물 물품

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'❤️캣타워❤️ 코너형 캣타워 이뻐요 배달은 25만.가지러오시면 22만입니다'
,'코너형으로 구석에 자리 차지 안하고
설치하기 좋아요~
기스난곳 있으니 사진 참고하세요
제일 윗칸 카페트는 없습니다
사용하는데는 전혀 지장 없습니다
지금 카펫포함 45만원 판매하는 제품이예요
집에 캣타워 캣휠 등
애기들 용품이 너무 많아서 판매합니다

상세설명은 지금 상품판매페이지
URL올릴께요 확인하세요

기본형. 뒷판없고. 카펫만 추가했던 상품입니다
가로 세로 60센치정도. 높이 180센치정도 입니다
가져가셔서 청소는 직접하셔야해요~
애기들 병력 전혀 없습니다

유성구. 서구는 시간 조율해서 배달해드리구요
직접 가지러 오시면 22만원에 드립니다

완제품이라서 팰리세이드급 차량있으셔야
가져가실수 있어요

상세하게 읽어보시고 챗주세요
네이버에 캣네스트 검색하셔도 됩니다'
,'반려동물 물품','2023/02/01',195,250000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'catTower.jpg', '9999\99\77', 'catTower');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'catTower.jpg', '9999\99\77', 'catTower1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'대형견 애견미용용품 애견드라이기/애견바리깡'
,'산지는 2년좀 안됐고 실사용횟수가 많지않아요
드라이기는 초대형견도 말리실수있는 드라이기입니다
바리깡은 사이즈상관없이 사용가능하세요

각각 구매하시면 바리깡은 16만원 드라이기는 18만원입니다.
일괄 구매하시면 30만원에 드립니다.
에누리없어요
사실분만 연락주세요'
,'반려동물 물품','2023/02/01',69,300000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'airtank.jpg', '9999\99\77', 'airtank');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'airtank.jpg', '9999\99\77', 'airtank1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'강아지가방 강아지캐리어 강아지카시트 애견카시트 애견가방'
,'구입한지 한달 조금 넘었습니다.
라피페토 제품입니다.
M 사이즈라서 16만원 넘게 주고 구입했습니다.
깔끔하고 예뻐요. 2번 사용했습니다.
애견가방으로 사용하고 카시트로도 사용 가능합니다
예쁩니다'
,'반려동물 물품','2023/02/02',578,76000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'apfhd.jpg', '9999\99\77', 'apfhd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'apfhd.jpg', '9999\99\77', 'apfhd1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'캣돌 캣타워'
,'캣타워에 필요한거 추가했어요
수직스크래처
식탁
슬라이드보드
발판
해먹
하우스(쿠션)

총39만원 주고 구매했고
6개월 정도 썼습니다
고장난거 하나 없이
상태 너무 좋구요
우드에 화이트라 인테리어에도
이쁩니다 !

6만9천 주고 구매한
투명해먹까지 같이드려요'
,'반려동물 물품','2023/01/31',248,200000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zotxkdnj.jpg', '9999\99\77', 'zotxkdnj');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zotxkdnj.jpg', '9999\99\77', 'zotxkdnj1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'고양이 자동화장실 (캣링크 영 고양이 자동화장실 catlink litter box)'
,'구매시기 2022년8월10일
사용 일주일사용 (집이 협소해서 놓아둘때가 마당치 않아서)
사용후기 모래를 충분이 보충해주면 사용이 편리 매일 화장실 청소를하지 않아 서 덜 힘듬 모래는 벤토나이트 필수
물품 본체 봉투 필터기1개'
,'반려동물 물품','2023/01/31',80,130000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'catlink.jpg', '9999\99\77', 'catlink');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'catlink.jpg', '9999\99\77', 'catlink1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'강아지 애견 켄넬 이동가방 접이식 애견가방'
,'우리애기 어릴때 썼어요.
대형이라고 샀는데 푸들이라 다리가길어서,,,
몸무게가 5.2키로 되니 작아졌네요.

투명이라 다 보여서 좋아요.
아주 가볍고 통기성 좋아요.
애기때 병원다닐때 사용하고 그후론 사용하지않아서 아주 깨끗합니다.
숄더끈 당연히 있어요. 한번도 않썼어요.

사이즈: 42x26x35cm
접었을땨: 42x7x35cm
무게: 0.9kg'
,'반려동물 물품','2023/01/30',105,10500,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dorusrkqkd.jpg', '9999\99\77', 'dorusrkqkd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dorusrkqkd.jpg', '9999\99\77', 'dorusrkqkd1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'반려견 반려묘 고양이 강아지 모자 개모자 반려동물 용품'
,'개당 가격입니다. 네고는 정중히 사양해여

크기: 17x 11

새상품입니다.
봉투는 분실했어요.

공덕역 마포경찰서 애오개역에서 직거래 합니다.'
,'반려동물 물품','2023/01/29',105,10500,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rnlduq.jpg', '9999\99\77', 'rnlduq');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rnlduq.jpg', '9999\99\77', 'rnlduq1');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rnlduq.jpg', '9999\99\77', 'rnlduq2');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'고양이 정수기 반려동물 정수기 판매합니다 (필터 1개 같이 드려요)'
,'스테인리스 고양이 정수기입니다

처음에 일주일 정도 적응하다가
엄청 잘 먹었어요

새로운 정수기로 바꿔주면서 판매합니다

정수기 입문하실 분들 추천드려요

서현동 거래 가능합니다'
,'반려동물 물품','2023/01/29',105,10500,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wjdtnrl.jpg', '9999\99\77', 'wjdtnrl');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'wjdtnrl.jpg', '9999\99\77', 'wjdtnrl1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'강아지유모차 애견유모차'
,'새로운 유모차를 선물받아서
기존에 보관해 두었던 유모차를 판매합니다

- 최대가능무게 15kg
- 360도 회전 3륜 구동 서스펜션 휠
- 물, 오염 방지 방수소재 옥스포드 원단
- 분리형 내부 쿠션
- 원터치 이지 폴딩, 풋 브레이크
- 컵홀더, 수납바구니
- 이탈방지 안전목줄 2개

강아지, 고양이 모두 사용 가능합니다'
,'반려동물 물품','2023/01/29',13,49000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rnldya.jpg', '9999\99\77', 'rnldya');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rnldya.jpg', '9999\99\77', 'rnldya1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'문걸이 캣타워 공간활용 캣타워'
,'*상태 9/10

문 두께 측정 후 구매하세요!
사진 첨부합니다.

*LH 2단지 아파트로 오시면 됩니다.
*교환 및 할인 불가'
,'반려동물 물품','2023/01/29',491,60000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zotzot.jpg', '9999\99\77', 'zotzot');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zotzot.jpg', '9999\99\77', 'zotzot1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'[ 배변패드 ] 강아지 소형 배변패드 92장'
,'- 배변패드 사이즈 : 가로 41cm 세로 34cm
( 가장자리를 제외하고 흡수되는 면적 크기 입니다! )
- 배변패드 총 개수 : 92장
- 판매이유 : 저희 애들은 두 마리라서 대형을 쓰기 때문에 판매합니다.'
,'반려동물 물품','2023/01/29',29,6000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qoqusvoem.jpg', '9999\99\77', 'qoqusvoem');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qoqusvoem.jpg', '9999\99\77', 'qoqusvoem1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'반려동물 용품'
,'울집 아기가 쬐끔 갉갉한 곳 있어요
아기가 안써서 깨끗합니다~
방석쿠션도 있고요
가로 52cm. 세로 60cm 정도입니다
택비는 별도에요~
쿨거래하심 근처 역까지 직접 가져다 드릴게요
중고이니만큼 반품불가입니다
일반택배만 가능(요금별도)'
,'반려동물 물품','2023/01/28',25,30000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'anjwldlrjs.jpg', '9999\99\77', 'anjwldlrjs');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'anjwldlrjs.jpg', '9999\99\77', 'anjwldlrjs1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'올치허그하네스+리드줄'
,'미개봉 새제품'
,'반려동물 물품','2023/01/28',25,30000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'alchi.jpg', '9999\99\77', 'alchi');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'alchi.jpg', '9999\99\77', 'alchi1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'캣타워 팝니다'
,'작년3월에 샀는데 다른집에 옮겨살아서 거의 쓰지못했는데 애가 커버려 다른캣따워로 바꾸는바람에 그대로있어요
아이용품 다른것도 같이 올려져있으니 같이 봐주시구요 가격제안도 받습니다'
,'반려동물 물품','2023/01/28',172,48000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'xkdnjzot.jpg', '9999\99\77', 'xkdnjzot');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'xkdnjzot.jpg', '9999\99\77', 'xkdnjzot1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'고양이모래 모래탈취제 디오더라이져 모래 고양이 애완동물용품'
,'4봉 오천원입니다. 가격 푹내립니다.
공산품이고 모래류라 유통기한은없습니다.
제조년월 18년11월 19년 2월
향 선택가능합니다.
재고 많이있습니다. cj택배발송가능합니다'
,'반려동물 물품','2023/01/28',147,5000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ahfoxkf.jpg', '9999\99\77', 'ahfoxkf');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'ahfoxkf.jpg', '9999\99\77', 'ahfoxkf1');

------------------------------------------------------------------------------------------------
--기타 중고물품
INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'공드럼통 빈드럼통 간판드럼통'
,'개당가격입니다
시트지 붙여서 간판이나 인테리어로 좋습니다'
,'기타 중고물품','2023/01/28',1632,15000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'emfjaxhd.jpg', '9999\99\66', 'emfjaxhd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'emfjaxhd.jpg', '9999\99\66', 'emfjaxhd1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'아반떼MD15인치휠타이어,명동중고휠타이어'
,'명동중고휠&타이어 입니다
아반떼mD15인치 휠,타이어세트입니다
굴절및잔기스1도없는
휠,타이어 모두신품이구요~
현대,기아차종 장착됩니다
기존휠 대품없이 단순구매는35만원입니다'
,'기타 중고물품','2023/01/28',123,300000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'xkdldj.jpg', '9999\99\66', 'xkdldj');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'xkdldj.jpg', '9999\99\66', 'xkdldj1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'컨테이너 콘테이너 3*9 이동식주택'
,'3*9 이동식주택
이중단열, 전기온돌 신품시공
운반하차비 별도'
,'기타 중고물품','2023/01/28',1990,6200000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zjsxp.jpg', '9999\99\66', 'zjsxp');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'zjsxp.jpg', '9999\99\66', 'zjsxp1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'유희왕 필수 범용카드부터 잡카드 일괄팝니다. #유희왕 #추억의 제품 판매 #최소가격6만원'
,'사이버드레곤 인피니티 레어
키메라테크 메가프리트 드래곤 십자 시크릿레어
욕졸항아리 십자 시크릿레어 울트라레어 두개
해피 울레
번개 울레
블랙홀 십자 시크릿레어
포영 울레
하루우라라 신일러 십자 시크릿 구일러 울레 두개
증지 울레
말살 울레
하나 미즈키 울레
무덤의 지명자 십자 시크릿레어
밀레니엄 아이즈 새크리파이스 울레
블매걸 울레
카우스 솔저 울레
카우스 솔저 개벽 울레
용기사 블매걸 십자 시크릿
성전검사 아우탐 울레
카우스의 의식 노말
섬도 인게이지 울레
카드 프택포함
네고가능
#유희왕카드
#추억의제품
#범용카드
환불x 찌르기x
구매의사가 있는분들만 챗 주세요
구매하면 카드 2개 덤으로 드려요
매너채팅엄수 시간 엄수 부탁드립니당'
,'기타 중고물품','2023/01/28',1990,6200000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dbgmldhkd.jpg', '9999\99\66', 'dbgmldhkd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dbgmldhkd.jpg', '9999\99\66', 'dbgmldhkd1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'카페용 업소용 커피 머신 에스프레소 머신'
,'새거 구매해서 카페에서 1년 정도 사용했어요.

다이나믹통상 커피머신기 로얄싱크로 Concorde 2GR, 600만원 이상 되는 고가제품으로 잘 작동되고 쓰면서 문제 있던 적 없고, 업종 변경으로 정리 합니다.

그 외에도 베이커리 카페 관련 장비, 용품들 많이 있으니 관심 있으시면 연락 주세요!!'
,'기타 중고물품','2023/01/29',749,2573000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dynamic.jpg', '9999\99\66', 'dynamic');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dynamic.jpg', '9999\99\66', 'dynamic1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'빈티지마네킹 가죽마네킹 빈티지소품 프렌치빈티지 앤틱빈티지소품 스튜디오소품 카페인테리어 카페소품'
,'세월감이 자연스럽게 뭍어난 마네킹소품입니다.

가지고 있던 매물 중, 관련종사자분께서 좋은평가를 해주신 제품입니다. 통가죽 위로 매거진 또는 뉴스페이퍼를 덧데어 작업된 마네킹입니다.

외에 빈티지 앤틱 카페 스튜디오 관련소품 용품 판매중이니 판매목록 참고하여 다량 구매해주신다면 네고 해드리고있습니다. 문의주세요 :)'
,'기타 중고물품','2023/01/29',348,350000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'akspzld.jpg', '9999\99\66', 'akspzld');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'akspzld.jpg', '9999\99\66', 'akspzld1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'수석 산수석'
,'산수석 가공석 판매 합니다.
채팅주세요'
,'기타 중고물품','2023/01/30',430,190000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tntjr.jpg', '9999\99\66', 'tntjr');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'tntjr.jpg', '9999\99\66', 'tntjr1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'구형 일제 천체망원경'
,'요즘 물건아니고 40년전? 일제 천체망원경 입니다
구경 60미리, 초점거리 800미리
원래 전용 삼각대가 없어서 자작플레이트 달아서 일반카메라삼각대에 장착할수 있게했습니다
부속품은 사진외에 5미리 접안렌즈 1개추가이며
사진에는 20미리접안렌즈 달려있는데 렌즈에 기스가 많지만 보는데는 지장없네요
삼각대도 오래전 일제이며 삼각대 제외시는 3만원 빼드립니다
보시고 마음에드시면 가져가세요'
,'기타 중고물품','2023/01/30',41,130000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlfwp.jpg', '9999\99\66', 'dlfwp');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlfwp.jpg', '9999\99\66', 'dlfwp1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'[VIP회원권 양도] 리챠드프로헤어 불당신도시점 회원권 양도'
,'안녕하세요!
신불당 리챠드 프로헤어 회원권 양도 합니다.
지점에 양도 가능 여부 확인 하였고,
양도 방법은 리챠드 방문하여 함께 회원정보
변경해드리도록 하겠습니다 :)

사용가능 금액 : 505,000 원
판매 금액 : 400,000 원 (-105,000원)
사유 : 이사로 인한 지역 이동 입니다!'
,'기타 중고물품','2023/01/30',58,400000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'flckem.jpg', '9999\99\66', 'flckem');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'flckem.jpg', '9999\99\66', 'flckem1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'북한돈 북한지폐 새지폐 새돈 옛날돈 옛날지폐 (미사용)'
,'" 구매할께요 " 말고는 답변 안드려요.
당일이후 거래는 무조건 예약금
1000원 받고 예약중 변경해드립니다.

북한지폐 미사용지폐입니다.
지폐 전종 일괄가격입니다.
수집종료로 팔아봅니다.

직거래 사상구 덕포동 신익아파트
주말 남구 용당동 뚜레쥬르 앞
GS반값택배 2천원

온라인 거래인관계로 반품x환불x교환x
미처 발견하지못한 흠이 있을수있으니
이리저리 예민하신분은 쇼핑몰 추천드려요.'
,'기타 중고물품','2023/01/30',214,33000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qnrgksehs.jpg', '9999\99\66', 'qnrgksehs');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'qnrgksehs.jpg', '9999\99\66', 'qnrgksehs1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'이동식 내장엠프스피커(충전식)'
,'그 유명했던 펨토제품
버스킹 엠프스피커입니다
사용감은 있으나 출력빵빵해요
밧데리는 최근 교환~고장없음
직거래 가능합니다'
,'기타 중고물품','2023/01/31',370,171000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'lee@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlehdtlrd.jpg', '9999\99\66', 'dlehdtlrd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'dlehdtlrd.jpg', '9999\99\66', 'dlehdtlrd1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'포켓몬 띠부실,짱구,키티 스티커 일괄 만원 니드킹,가디,망키,두리몬,세레비,덩쿠리,키티,짱구 스티커'
,'일괄 만 원이면 엄청 싼 가격입니다
니드킹 2천원 가디 2천원 망키 2천원 두리몬 천원 세레비 3천원 덩쿠리 3천원 쿠키 스티커 2개는 한개당 천원 짱구 스티커도 천원씩 키티 스티커도 천원씩
무조건 현금만 가능합니다 관심 누르고 안사고 그러지 말고 빨리 사세요 시간이 너무 없어서 직거래 힘드신 분들은 2만 원이나 3만 원 더 주셔야 택배 해드립니다
빠른 직거래 원함 연신내 갈현초 후문,정문쪽,롯데슈퍼,구산초,길마공원,구산역 4번출구 앞 걸어서 가능
제가 판매하는 물건들 보시고 사실 거 있으면 편하게 채팅 주세요! 옷 포카 인형 여러 가지 있어요'
,'기타 중고물품','2023/01/31',59,15000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'pack@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'andigh.jpg', '9999\99\66', 'andigh');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'andigh.jpg', '9999\99\66', 'andigh1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'애니굿즈소장용] 오소마츠상 굿즈 피규어'
,'서울에서 구매했었던 오소마츠피규어입니다!
구매 후 잘 안 보게 돼서 팔게 되었습니다!!
꼭 피규어로만 쓰는 게 아니라 인형들 배경으로서도 좋을 것 같습니다!!
정성스럽게 포장해드리겠습니다!
편안하게 연락 주세요!!

시간이 없어서 직거래시간이 어긋날수도있습니다!
GS 반값 택배와 CU끼리 택배로도 거래합니다!
택배 거래시 배송비는 1900원입니다!'
,'기타 중고물품','2023/02/01',65,13000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'jeong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rntwm.jpg', '9999\99\66', 'rntwm');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'rntwm.jpg', '9999\99\66', 'rntwm1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'더 핏 필라테스 회원권 양도 142회 양도비 포함'
,'더 핏기구 필라테스 회원권 양도합니다 명륜점이고
142회 1년 남았습니다 양도비 포함 올려요

1:8 수업이고 예약한 인원이 적으면 혼자도 수업이 가능합니다
자신의 스케줄에 맞게 어플로 수업 예약,취소 가능합니다

이사가야해서 판매합니다'
,'기타 중고물품','2023/02/01',285,1150000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'choi@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'akwlakrr.jpg', '9999\99\66', 'akwlakrr');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'akwlakrr.jpg', '9999\99\66', 'akwlakrr1');

INSERT INTO productDetail(p_id, p_name, description, category, regdate, views, price,lat,lng)
VALUES('pid'||pid_seq.NEXTVAL,'금귤 나무입니다'
,'높이 130cm 가량 입니다
매년 초여름부터 그향기에 취할 듯 싶은 하얀꽃이 피고 탱글탱글한 열매를 맺기 시작해 11월부터 다음 해 4월까지 저렇게 탐스럽게 익은 열매들을 볼 수 있어요

가정집도 좋고
개업 선물, 카페나 사무실에 두기에도 멋진
작품같은 나무예요.
바라보는 것만으로도 좋지만 신선하고 향기좋은 귤을 한 두개씩 따먹을 때의 즐거움은 이루 말할 수 없지요^^

해충없이 잘 자랍니다.
해마다 더 풍성해지고 따라서 열매도 많이 열립니다 .운반하기 좋게 잘 다듬어 두었어요

인터넷 검사 결과물과 가격도 사진에 올립니다.
( 비교 하시라고요)

베란다에 화분이 너무 많아서
파격적으로 가격을 내렸습니다
더이상 내리진 않으려구요.
가치를 알아보시는 분이 꼭 있으리라 생각합니다.

꽃 맺기 시작한 지난 여름부터의 사진이며
맨 끝 사진이 현재 (1 .31) 입니다

문의주세요 ^^'
,'기타 중고물품','2023/02/01',336,1100000,'37.51452963901751','127.10594025453048');
INSERT INTO product VALUES(product_seq.NEXTVAL, 'hong@naver.com', 'pid'||pid_seq.CURRVAL);
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'RldRkd.jpg', '9999\99\66', 'RldRkd');
INSERT INTO productPic VALUES('pid'||pid_seq.CURRVAL, 'RldRkd.jpg', '9999\99\66', 'RldRkd1');