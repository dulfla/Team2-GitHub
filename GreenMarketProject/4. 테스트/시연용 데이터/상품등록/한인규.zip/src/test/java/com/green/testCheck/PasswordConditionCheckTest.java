package com.green.testCheck;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.green.check.PasswordConditionCheck;
import com.green.status.PasswordStatus;

public class PasswordConditionCheckTest {

	PasswordConditionCheck pcc = new PasswordConditionCheck();
	
	String password1;
	String password2;
	
	PasswordStatus ps1;
	PasswordStatus ps2;
	@Test	/*모두 통과*/
	public void conditionThenStrong() {
		
		password1 = "ab12!@AB";
		password2 = "abc1!Add";		
		ps1 = pcc.passwordCheck(password1);
		ps2 = pcc.passwordCheck(password2);
			
		assertEquals(PasswordStatus.STRONG, ps1);
		assertEquals(PasswordStatus.STRONG, ps2);
	}
	@Test	/*8글자 미만*/	
	public void conditionforLengthThenNormal() {
		password1 = "ab12!@A";
		password2 = "AB12!c";		
		ps1 = pcc.passwordCheck(password1);
		ps2 = pcc.passwordCheck(password2);
		
		assertEquals(PasswordStatus.NORMAL, ps1);
		assertEquals(PasswordStatus.NORMAL, ps2);
	}
	@Test	/*숫자 미포함*/
	public void conditionforNumberThenNormal() {
		password1 = "ab!@ABqwer";
		password2 = "Ab!Zx@cD";		
		ps1 = pcc.passwordCheck(password1);
		ps2 = pcc.passwordCheck(password2);
		
		assertEquals(PasswordStatus.NORMAL, ps1);
		assertEquals(PasswordStatus.NORMAL, ps2);
	}
	@Test	/*대문자 미포함*/
	public void conditionforUppercaseThenNormal() {
		password1 = "ab12!@df";
		password2 = "1b!2x@c4";		
		ps1 = pcc.passwordCheck(password1);
		ps2 = pcc.passwordCheck(password2);
		
		assertEquals(PasswordStatus.NORMAL, ps1);
		assertEquals(PasswordStatus.NORMAL, ps2);
	}
	@Test	/*숫자, 대문자 미포함*/
	public void conditionOnlyLengthThenWeak() {
		password1 = "abcdefghi";		
		ps1 = pcc.passwordCheck(password1);
		
		assertEquals(PasswordStatus.WEAK, ps1);
	}
	@Test	/*8글자 미만, 대문자 미포함*/
	public void conditionOnlyNumThenWeak() {
		password1 = "12345";
		ps1 = pcc.passwordCheck(password1);
		
		assertEquals(PasswordStatus.WEAK, ps1);
	}
	@Test	/*8글자 미만, 숫자 미포함*/
	public void conditionOnlyUppercaseThenWeak() {
		password1 = "ABCDE";		
		ps1 = pcc.passwordCheck(password1);
		
		assertEquals(PasswordStatus.WEAK, ps1);
	}
	@Test	/*8글지 미만, 숫자,대문자 미포함*/
	public void NoConditionThenWeak() {
		password1 = "abc";		
		ps1 = pcc.passwordCheck(password1);
		
		assertEquals(PasswordStatus.WEAK, ps1);
	}
	@Test	/*null*/
	public void nullInputThenInvalid() {
		password1 = null;
		ps1 = pcc.passwordCheck(password1);
		
		assertEquals(PasswordStatus.INVALID, ps1);
	}@Test	/*공백*/
	public void emptyInputThenInvalid() {
		password1 = "";
		ps1 = pcc.passwordCheck(password1);
		
		assertEquals(PasswordStatus.INVALID, ps1);
	}	
	/*
	 * 애플리케이션 테스트 관리 평가
	 * 시험일 : 2023년 02월 02일
	 * 제한시간 : 2023년 02월 02일
	 * 훈련생명 : 한인규
	 * */
}
