package com.green.check;

import com.green.status.PasswordStatus;

public class PasswordConditionCheck {

	public PasswordStatus passwordCheck(String password){
		
		boolean lengthChk = true;
		boolean numberChk = true;
		boolean capitalChk = true;
		
		/*공백, null*/
		if(password == null || password.isEmpty()) {
			return PasswordStatus.INVALID;
		}
		/*8글자 미만*/		
		if(password.length() >= 8) {
			lengthChk = false;
		}		
		/*숫자 미포함*/		
		for(char c : password.toCharArray()) {
			if(c >= '0' && c <= '9') {
				numberChk = false;
				break;
			}
		}
		/*대문자 미포함*/		
		for(char ch : password.toCharArray()) {
			if(Character.isUpperCase(ch)) {
				capitalChk = false;
				break;
			}
		}
		
		if((lengthChk && numberChk && capitalChk) 
				|| (lengthChk && numberChk) 
				|| (lengthChk && capitalChk) 
				|| (numberChk && capitalChk)){
			return PasswordStatus.WEAK;
		}else if(lengthChk || numberChk || capitalChk) {
			return PasswordStatus.NORMAL;
		}								
		return PasswordStatus.STRONG;
	}
	/*
	 * 애플리케이션 테스트 관리 평가
	 * 시험일 : 2023년 02월 02일
	 * 제한시간 : 2023년 02월 02일
	 * 훈련생명 : 한인규
	 * */
}
