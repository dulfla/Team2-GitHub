package com.green.status;

public enum PasswordStatus {
	STRONG, NORMAL, WEAK, INVALID
	/*
	 * 애플리케이션 테스트 관리 평가
	 * 시험일 : 2023년 02월 02일
	 * 제한시간 : 2023년 02월 02일
	 * 훈련생명 : 한인규
	 * */
}
